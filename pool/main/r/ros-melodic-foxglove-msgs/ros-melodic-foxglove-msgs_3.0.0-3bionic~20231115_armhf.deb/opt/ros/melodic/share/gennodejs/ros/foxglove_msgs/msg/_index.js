
"use strict";

let TrianglesMarker = require('./TrianglesMarker.js');
let CameraCalibration = require('./CameraCalibration.js');
let TextMarker = require('./TextMarker.js');
let SceneEntityUpdate = require('./SceneEntityUpdate.js');
let LinePrimitive = require('./LinePrimitive.js');
let ModelMarker = require('./ModelMarker.js');
let TriangleListPrimitive = require('./TriangleListPrimitive.js');
let ConeListMarker = require('./ConeListMarker.js');
let ImageAnnotations = require('./ImageAnnotations.js');
let Point2 = require('./Point2.js');
let KeyValuePair = require('./KeyValuePair.js');
let TriangleListMarker = require('./TriangleListMarker.js');
let SphereMarker = require('./SphereMarker.js');
let FrameTransform = require('./FrameTransform.js');
let ArrowMarker = require('./ArrowMarker.js');
let MarkerDeletion = require('./MarkerDeletion.js');
let CubePrimitive = require('./CubePrimitive.js');
let PackedElementField = require('./PackedElementField.js');
let LocationFix = require('./LocationFix.js');
let CompressedImage = require('./CompressedImage.js');
let FrameTransformList = require('./FrameTransformList.js');
let LaserScan = require('./LaserScan.js');
let PosesInFrame = require('./PosesInFrame.js');
let SphereListMarker = require('./SphereListMarker.js');
let PoseInFrame = require('./PoseInFrame.js');
let Grid = require('./Grid.js');
let Transform = require('./Transform.js');
let ArrowPrimitive = require('./ArrowPrimitive.js');
let ModelPrimitive = require('./ModelPrimitive.js');
let Log = require('./Log.js');
let SceneEntity = require('./SceneEntity.js');
let TextAnnotation = require('./TextAnnotation.js');
let TextPrimitive = require('./TextPrimitive.js');
let Color = require('./Color.js');
let FrameTransforms = require('./FrameTransforms.js');
let CubeMarker = require('./CubeMarker.js');
let LineMarker = require('./LineMarker.js');
let SphereAttributes = require('./SphereAttributes.js');
let ConeAttributes = require('./ConeAttributes.js');
let ConeMarker = require('./ConeMarker.js');
let PointCloud = require('./PointCloud.js');
let Vector2 = require('./Vector2.js');
let CylinderMarker = require('./CylinderMarker.js');
let ConePrimitive = require('./ConePrimitive.js');
let CircleAnnotation = require('./CircleAnnotation.js');
let SceneEntities = require('./SceneEntities.js');
let RawImage = require('./RawImage.js');
let SceneEntityDeletion = require('./SceneEntityDeletion.js');
let CubeListMarker = require('./CubeListMarker.js');
let PrimitiveDeletion = require('./PrimitiveDeletion.js');
let CubeAttributes = require('./CubeAttributes.js');
let PointsAnnotation = require('./PointsAnnotation.js');
let ImageMarkerArray = require('./ImageMarkerArray.js');
let Markers = require('./Markers.js');
let SpherePrimitive = require('./SpherePrimitive.js');
let GeoJSON = require('./GeoJSON.js');
let SceneUpdate = require('./SceneUpdate.js');
let CylinderPrimitive = require('./CylinderPrimitive.js');
let CompressedVideo = require('./CompressedVideo.js');

module.exports = {
  TrianglesMarker: TrianglesMarker,
  CameraCalibration: CameraCalibration,
  TextMarker: TextMarker,
  SceneEntityUpdate: SceneEntityUpdate,
  LinePrimitive: LinePrimitive,
  ModelMarker: ModelMarker,
  TriangleListPrimitive: TriangleListPrimitive,
  ConeListMarker: ConeListMarker,
  ImageAnnotations: ImageAnnotations,
  Point2: Point2,
  KeyValuePair: KeyValuePair,
  TriangleListMarker: TriangleListMarker,
  SphereMarker: SphereMarker,
  FrameTransform: FrameTransform,
  ArrowMarker: ArrowMarker,
  MarkerDeletion: MarkerDeletion,
  CubePrimitive: CubePrimitive,
  PackedElementField: PackedElementField,
  LocationFix: LocationFix,
  CompressedImage: CompressedImage,
  FrameTransformList: FrameTransformList,
  LaserScan: LaserScan,
  PosesInFrame: PosesInFrame,
  SphereListMarker: SphereListMarker,
  PoseInFrame: PoseInFrame,
  Grid: Grid,
  Transform: Transform,
  ArrowPrimitive: ArrowPrimitive,
  ModelPrimitive: ModelPrimitive,
  Log: Log,
  SceneEntity: SceneEntity,
  TextAnnotation: TextAnnotation,
  TextPrimitive: TextPrimitive,
  Color: Color,
  FrameTransforms: FrameTransforms,
  CubeMarker: CubeMarker,
  LineMarker: LineMarker,
  SphereAttributes: SphereAttributes,
  ConeAttributes: ConeAttributes,
  ConeMarker: ConeMarker,
  PointCloud: PointCloud,
  Vector2: Vector2,
  CylinderMarker: CylinderMarker,
  ConePrimitive: ConePrimitive,
  CircleAnnotation: CircleAnnotation,
  SceneEntities: SceneEntities,
  RawImage: RawImage,
  SceneEntityDeletion: SceneEntityDeletion,
  CubeListMarker: CubeListMarker,
  PrimitiveDeletion: PrimitiveDeletion,
  CubeAttributes: CubeAttributes,
  PointsAnnotation: PointsAnnotation,
  ImageMarkerArray: ImageMarkerArray,
  Markers: Markers,
  SpherePrimitive: SpherePrimitive,
  GeoJSON: GeoJSON,
  SceneUpdate: SceneUpdate,
  CylinderPrimitive: CylinderPrimitive,
  CompressedVideo: CompressedVideo,
};
