// Auto-generated. Do not edit!

// (in-package foxglove_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let KeyValuePair = require('./KeyValuePair.js');
let ArrowPrimitive = require('./ArrowPrimitive.js');
let CubePrimitive = require('./CubePrimitive.js');
let SpherePrimitive = require('./SpherePrimitive.js');
let CylinderPrimitive = require('./CylinderPrimitive.js');
let LinePrimitive = require('./LinePrimitive.js');
let TriangleListPrimitive = require('./TriangleListPrimitive.js');
let TextPrimitive = require('./TextPrimitive.js');
let ModelPrimitive = require('./ModelPrimitive.js');

//-----------------------------------------------------------

class SceneEntity {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.frame_id = null;
      this.id = null;
      this.lifetime = null;
      this.frame_locked = null;
      this.metadata = null;
      this.arrows = null;
      this.cubes = null;
      this.spheres = null;
      this.cylinders = null;
      this.lines = null;
      this.triangles = null;
      this.texts = null;
      this.models = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('frame_id')) {
        this.frame_id = initObj.frame_id
      }
      else {
        this.frame_id = '';
      }
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = '';
      }
      if (initObj.hasOwnProperty('lifetime')) {
        this.lifetime = initObj.lifetime
      }
      else {
        this.lifetime = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('frame_locked')) {
        this.frame_locked = initObj.frame_locked
      }
      else {
        this.frame_locked = false;
      }
      if (initObj.hasOwnProperty('metadata')) {
        this.metadata = initObj.metadata
      }
      else {
        this.metadata = [];
      }
      if (initObj.hasOwnProperty('arrows')) {
        this.arrows = initObj.arrows
      }
      else {
        this.arrows = [];
      }
      if (initObj.hasOwnProperty('cubes')) {
        this.cubes = initObj.cubes
      }
      else {
        this.cubes = [];
      }
      if (initObj.hasOwnProperty('spheres')) {
        this.spheres = initObj.spheres
      }
      else {
        this.spheres = [];
      }
      if (initObj.hasOwnProperty('cylinders')) {
        this.cylinders = initObj.cylinders
      }
      else {
        this.cylinders = [];
      }
      if (initObj.hasOwnProperty('lines')) {
        this.lines = initObj.lines
      }
      else {
        this.lines = [];
      }
      if (initObj.hasOwnProperty('triangles')) {
        this.triangles = initObj.triangles
      }
      else {
        this.triangles = [];
      }
      if (initObj.hasOwnProperty('texts')) {
        this.texts = initObj.texts
      }
      else {
        this.texts = [];
      }
      if (initObj.hasOwnProperty('models')) {
        this.models = initObj.models
      }
      else {
        this.models = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SceneEntity
    // Serialize message field [timestamp]
    bufferOffset = _serializer.time(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [frame_id]
    bufferOffset = _serializer.string(obj.frame_id, buffer, bufferOffset);
    // Serialize message field [id]
    bufferOffset = _serializer.string(obj.id, buffer, bufferOffset);
    // Serialize message field [lifetime]
    bufferOffset = _serializer.duration(obj.lifetime, buffer, bufferOffset);
    // Serialize message field [frame_locked]
    bufferOffset = _serializer.bool(obj.frame_locked, buffer, bufferOffset);
    // Serialize message field [metadata]
    // Serialize the length for message field [metadata]
    bufferOffset = _serializer.uint32(obj.metadata.length, buffer, bufferOffset);
    obj.metadata.forEach((val) => {
      bufferOffset = KeyValuePair.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [arrows]
    // Serialize the length for message field [arrows]
    bufferOffset = _serializer.uint32(obj.arrows.length, buffer, bufferOffset);
    obj.arrows.forEach((val) => {
      bufferOffset = ArrowPrimitive.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [cubes]
    // Serialize the length for message field [cubes]
    bufferOffset = _serializer.uint32(obj.cubes.length, buffer, bufferOffset);
    obj.cubes.forEach((val) => {
      bufferOffset = CubePrimitive.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [spheres]
    // Serialize the length for message field [spheres]
    bufferOffset = _serializer.uint32(obj.spheres.length, buffer, bufferOffset);
    obj.spheres.forEach((val) => {
      bufferOffset = SpherePrimitive.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [cylinders]
    // Serialize the length for message field [cylinders]
    bufferOffset = _serializer.uint32(obj.cylinders.length, buffer, bufferOffset);
    obj.cylinders.forEach((val) => {
      bufferOffset = CylinderPrimitive.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [lines]
    // Serialize the length for message field [lines]
    bufferOffset = _serializer.uint32(obj.lines.length, buffer, bufferOffset);
    obj.lines.forEach((val) => {
      bufferOffset = LinePrimitive.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [triangles]
    // Serialize the length for message field [triangles]
    bufferOffset = _serializer.uint32(obj.triangles.length, buffer, bufferOffset);
    obj.triangles.forEach((val) => {
      bufferOffset = TriangleListPrimitive.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [texts]
    // Serialize the length for message field [texts]
    bufferOffset = _serializer.uint32(obj.texts.length, buffer, bufferOffset);
    obj.texts.forEach((val) => {
      bufferOffset = TextPrimitive.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [models]
    // Serialize the length for message field [models]
    bufferOffset = _serializer.uint32(obj.models.length, buffer, bufferOffset);
    obj.models.forEach((val) => {
      bufferOffset = ModelPrimitive.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SceneEntity
    let len;
    let data = new SceneEntity(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [frame_id]
    data.frame_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [id]
    data.id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [lifetime]
    data.lifetime = _deserializer.duration(buffer, bufferOffset);
    // Deserialize message field [frame_locked]
    data.frame_locked = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [metadata]
    // Deserialize array length for message field [metadata]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.metadata = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.metadata[i] = KeyValuePair.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [arrows]
    // Deserialize array length for message field [arrows]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.arrows = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.arrows[i] = ArrowPrimitive.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [cubes]
    // Deserialize array length for message field [cubes]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.cubes = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.cubes[i] = CubePrimitive.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [spheres]
    // Deserialize array length for message field [spheres]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.spheres = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.spheres[i] = SpherePrimitive.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [cylinders]
    // Deserialize array length for message field [cylinders]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.cylinders = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.cylinders[i] = CylinderPrimitive.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [lines]
    // Deserialize array length for message field [lines]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.lines = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.lines[i] = LinePrimitive.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [triangles]
    // Deserialize array length for message field [triangles]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.triangles = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.triangles[i] = TriangleListPrimitive.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [texts]
    // Deserialize array length for message field [texts]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.texts = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.texts[i] = TextPrimitive.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [models]
    // Deserialize array length for message field [models]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.models = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.models[i] = ModelPrimitive.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.frame_id);
    length += _getByteLength(object.id);
    object.metadata.forEach((val) => {
      length += KeyValuePair.getMessageSize(val);
    });
    length += 120 * object.arrows.length;
    length += 112 * object.cubes.length;
    length += 112 * object.spheres.length;
    length += 128 * object.cylinders.length;
    object.lines.forEach((val) => {
      length += LinePrimitive.getMessageSize(val);
    });
    object.triangles.forEach((val) => {
      length += TriangleListPrimitive.getMessageSize(val);
    });
    object.texts.forEach((val) => {
      length += TextPrimitive.getMessageSize(val);
    });
    object.models.forEach((val) => {
      length += ModelPrimitive.getMessageSize(val);
    });
    return length + 61;
  }

  static datatype() {
    // Returns string type for a message object
    return 'foxglove_msgs/SceneEntity';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0ef0f20344c30e92e1768ed896c46bd7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # foxglove_msgs/SceneEntity
    # A visual element in a 3D scene. An entity may be composed of multiple primitives which all share the same frame of reference.
    
    # Generated by https://github.com/foxglove/schemas
    
    # Timestamp of the entity
    time timestamp
    
    # Frame of reference
    string frame_id
    
    # Identifier for the entity. A entity will replace any prior entity on the same topic with the same `id`.
    string id
    
    # Length of time (relative to `timestamp`) after which the entity should be automatically removed. Zero value indicates the entity should remain visible until it is replaced or deleted.
    duration lifetime
    
    # Whether the entity should keep its location in the fixed frame (false) or follow the frame specified in `frame_id` as it moves relative to the fixed frame (true)
    bool frame_locked
    
    # Additional user-provided metadata associated with the entity. Keys must be unique.
    foxglove_msgs/KeyValuePair[] metadata
    
    # Arrow primitives
    foxglove_msgs/ArrowPrimitive[] arrows
    
    # Cube primitives
    foxglove_msgs/CubePrimitive[] cubes
    
    # Sphere primitives
    foxglove_msgs/SpherePrimitive[] spheres
    
    # Cylinder primitives
    foxglove_msgs/CylinderPrimitive[] cylinders
    
    # Line primitives
    foxglove_msgs/LinePrimitive[] lines
    
    # Triangle list primitives
    foxglove_msgs/TriangleListPrimitive[] triangles
    
    # Text primitives
    foxglove_msgs/TextPrimitive[] texts
    
    # Model primitives
    foxglove_msgs/ModelPrimitive[] models
    
    ================================================================================
    MSG: foxglove_msgs/KeyValuePair
    # foxglove_msgs/KeyValuePair
    # A key with its associated value
    
    # Generated by https://github.com/foxglove/schemas
    
    # Key
    string key
    
    # Value
    string value
    
    ================================================================================
    MSG: foxglove_msgs/ArrowPrimitive
    # foxglove_msgs/ArrowPrimitive
    # A primitive representing an arrow
    
    # Generated by https://github.com/foxglove/schemas
    
    # Position of the arrow's tail and orientation of the arrow. Identity orientation means the arrow points in the +x direction.
    geometry_msgs/Pose pose
    
    # Length of the arrow shaft
    float64 shaft_length
    
    # Diameter of the arrow shaft
    float64 shaft_diameter
    
    # Length of the arrow head
    float64 head_length
    
    # Diameter of the arrow head
    float64 head_diameter
    
    # Color of the arrow
    foxglove_msgs/Color color
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: foxglove_msgs/Color
    # foxglove_msgs/Color
    # A color in RGBA format
    
    # Generated by https://github.com/foxglove/schemas
    
    # Red value between 0 and 1
    float64 r
    
    # Green value between 0 and 1
    float64 g
    
    # Blue value between 0 and 1
    float64 b
    
    # Alpha value between 0 and 1
    float64 a
    
    ================================================================================
    MSG: foxglove_msgs/CubePrimitive
    # foxglove_msgs/CubePrimitive
    # A primitive representing a cube or rectangular prism
    
    # Generated by https://github.com/foxglove/schemas
    
    # Position of the center of the cube and orientation of the cube
    geometry_msgs/Pose pose
    
    # Size of the cube along each axis
    geometry_msgs/Vector3 size
    
    # Color of the arrow
    foxglove_msgs/Color color
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    ================================================================================
    MSG: foxglove_msgs/SpherePrimitive
    # foxglove_msgs/SpherePrimitive
    # A primitive representing a sphere or ellipsoid
    
    # Generated by https://github.com/foxglove/schemas
    
    # Position of the center of the sphere and orientation of the sphere
    geometry_msgs/Pose pose
    
    # Size (diameter) of the sphere along each axis
    geometry_msgs/Vector3 size
    
    # Color of the sphere
    foxglove_msgs/Color color
    
    ================================================================================
    MSG: foxglove_msgs/CylinderPrimitive
    # foxglove_msgs/CylinderPrimitive
    # A primitive representing a cylinder, elliptic cylinder, or truncated cone
    
    # Generated by https://github.com/foxglove/schemas
    
    # Position of the center of the cylinder and orientation of the cylinder. The flat face(s) are perpendicular to the z-axis.
    geometry_msgs/Pose pose
    
    # Size of the cylinder's bounding box
    geometry_msgs/Vector3 size
    
    # 0-1, ratio of the diameter of the cylinder's bottom face (min z) to the bottom of the bounding box
    float64 bottom_scale
    
    # 0-1, ratio of the diameter of the cylinder's top face (max z) to the top of the bounding box
    float64 top_scale
    
    # Color of the cylinder
    foxglove_msgs/Color color
    
    ================================================================================
    MSG: foxglove_msgs/LinePrimitive
    # foxglove_msgs/LinePrimitive
    # A primitive representing a series of points connected by lines
    
    # Generated by https://github.com/foxglove/schemas
    
    # 0-1, 1-2, ..., (n-1)-n
    uint8 LINE_STRIP=0
    
    # 0-1, 1-2, ..., (n-1)-n, n-0
    uint8 LINE_LOOP=1
    
    # 0-1, 2-3, 4-5, ...
    uint8 LINE_LIST=2
    
    # Drawing primitive to use for lines
    uint8 type
    
    # Origin of lines relative to reference frame
    geometry_msgs/Pose pose
    
    # Line thickness
    float64 thickness
    
    # Indicates whether `thickness` is a fixed size in screen pixels (true), or specified in world coordinates and scales with distance from the camera (false)
    bool scale_invariant
    
    # Points along the line
    geometry_msgs/Point[] points
    
    # Solid color to use for the whole line. One of `color` or `colors` must be provided.
    foxglove_msgs/Color color
    
    # Per-point colors (if specified, must have the same length as `points`). One of `color` or `colors` must be provided.
    foxglove_msgs/Color[] colors
    
    # Indices into the `points` and `colors` attribute arrays, which can be used to avoid duplicating attribute data.
    # 
    # If omitted or empty, indexing will not be used. This default behavior is equivalent to specifying [0, 1, ..., N-1] for the indices (where N is the number of `points` provided).
    uint32[] indices
    
    ================================================================================
    MSG: foxglove_msgs/TriangleListPrimitive
    # foxglove_msgs/TriangleListPrimitive
    # A primitive representing a set of triangles or a surface tiled by triangles
    
    # Generated by https://github.com/foxglove/schemas
    
    # Origin of triangles relative to reference frame
    geometry_msgs/Pose pose
    
    # Vertices to use for triangles, interpreted as a list of triples (0-1-2, 3-4-5, ...)
    geometry_msgs/Point[] points
    
    # Solid color to use for the whole shape. One of `color` or `colors` must be provided.
    foxglove_msgs/Color color
    
    # Per-vertex colors (if specified, must have the same length as `points`). One of `color` or `colors` must be provided.
    foxglove_msgs/Color[] colors
    
    # Indices into the `points` and `colors` attribute arrays, which can be used to avoid duplicating attribute data.
    # 
    # If omitted or empty, indexing will not be used. This default behavior is equivalent to specifying [0, 1, ..., N-1] for the indices (where N is the number of `points` provided).
    uint32[] indices
    
    ================================================================================
    MSG: foxglove_msgs/TextPrimitive
    # foxglove_msgs/TextPrimitive
    # A primitive representing a text label
    
    # Generated by https://github.com/foxglove/schemas
    
    # Position of the center of the text box and orientation of the text. Identity orientation means the text is oriented in the xy-plane and flows from -x to +x.
    geometry_msgs/Pose pose
    
    # Whether the text should respect `pose.orientation` (false) or always face the camera (true)
    bool billboard
    
    # Font size (height of one line of text)
    float64 font_size
    
    # Indicates whether `font_size` is a fixed size in screen pixels (true), or specified in world coordinates and scales with distance from the camera (false)
    bool scale_invariant
    
    # Color of the text
    foxglove_msgs/Color color
    
    # Text
    string text
    
    ================================================================================
    MSG: foxglove_msgs/ModelPrimitive
    # foxglove_msgs/ModelPrimitive
    # A primitive representing a 3D model file loaded from an external URL or embedded data
    
    # Generated by https://github.com/foxglove/schemas
    
    # Origin of model relative to reference frame
    geometry_msgs/Pose pose
    
    # Scale factor to apply to the model along each axis
    geometry_msgs/Vector3 scale
    
    # Solid color to use for the whole model if `override_color` is true.
    foxglove_msgs/Color color
    
    # Whether to use the color specified in `color` instead of any materials embedded in the original model.
    bool override_color
    
    # URL pointing to model file. One of `url` or `data` should be provided.
    string url
    
    # [Media type](https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types) of embedded model (e.g. `model/gltf-binary`). Required if `data` is provided instead of `url`. Overrides the inferred media type if `url` is provided.
    string media_type
    
    # Embedded model. One of `url` or `data` should be provided. If `data` is provided, `media_type` must be set to indicate the type of the data.
    uint8[] data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SceneEntity(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = {secs: 0, nsecs: 0}
    }

    if (msg.frame_id !== undefined) {
      resolved.frame_id = msg.frame_id;
    }
    else {
      resolved.frame_id = ''
    }

    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = ''
    }

    if (msg.lifetime !== undefined) {
      resolved.lifetime = msg.lifetime;
    }
    else {
      resolved.lifetime = {secs: 0, nsecs: 0}
    }

    if (msg.frame_locked !== undefined) {
      resolved.frame_locked = msg.frame_locked;
    }
    else {
      resolved.frame_locked = false
    }

    if (msg.metadata !== undefined) {
      resolved.metadata = new Array(msg.metadata.length);
      for (let i = 0; i < resolved.metadata.length; ++i) {
        resolved.metadata[i] = KeyValuePair.Resolve(msg.metadata[i]);
      }
    }
    else {
      resolved.metadata = []
    }

    if (msg.arrows !== undefined) {
      resolved.arrows = new Array(msg.arrows.length);
      for (let i = 0; i < resolved.arrows.length; ++i) {
        resolved.arrows[i] = ArrowPrimitive.Resolve(msg.arrows[i]);
      }
    }
    else {
      resolved.arrows = []
    }

    if (msg.cubes !== undefined) {
      resolved.cubes = new Array(msg.cubes.length);
      for (let i = 0; i < resolved.cubes.length; ++i) {
        resolved.cubes[i] = CubePrimitive.Resolve(msg.cubes[i]);
      }
    }
    else {
      resolved.cubes = []
    }

    if (msg.spheres !== undefined) {
      resolved.spheres = new Array(msg.spheres.length);
      for (let i = 0; i < resolved.spheres.length; ++i) {
        resolved.spheres[i] = SpherePrimitive.Resolve(msg.spheres[i]);
      }
    }
    else {
      resolved.spheres = []
    }

    if (msg.cylinders !== undefined) {
      resolved.cylinders = new Array(msg.cylinders.length);
      for (let i = 0; i < resolved.cylinders.length; ++i) {
        resolved.cylinders[i] = CylinderPrimitive.Resolve(msg.cylinders[i]);
      }
    }
    else {
      resolved.cylinders = []
    }

    if (msg.lines !== undefined) {
      resolved.lines = new Array(msg.lines.length);
      for (let i = 0; i < resolved.lines.length; ++i) {
        resolved.lines[i] = LinePrimitive.Resolve(msg.lines[i]);
      }
    }
    else {
      resolved.lines = []
    }

    if (msg.triangles !== undefined) {
      resolved.triangles = new Array(msg.triangles.length);
      for (let i = 0; i < resolved.triangles.length; ++i) {
        resolved.triangles[i] = TriangleListPrimitive.Resolve(msg.triangles[i]);
      }
    }
    else {
      resolved.triangles = []
    }

    if (msg.texts !== undefined) {
      resolved.texts = new Array(msg.texts.length);
      for (let i = 0; i < resolved.texts.length; ++i) {
        resolved.texts[i] = TextPrimitive.Resolve(msg.texts[i]);
      }
    }
    else {
      resolved.texts = []
    }

    if (msg.models !== undefined) {
      resolved.models = new Array(msg.models.length);
      for (let i = 0; i < resolved.models.length; ++i) {
        resolved.models[i] = ModelPrimitive.Resolve(msg.models[i]);
      }
    }
    else {
      resolved.models = []
    }

    return resolved;
    }
};

module.exports = SceneEntity;
