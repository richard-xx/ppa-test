// Auto-generated. Do not edit!

// (in-package foxglove_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Color = require('./Color.js');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class LinePrimitive {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.type = null;
      this.pose = null;
      this.thickness = null;
      this.scale_invariant = null;
      this.points = null;
      this.color = null;
      this.colors = null;
      this.indices = null;
    }
    else {
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('thickness')) {
        this.thickness = initObj.thickness
      }
      else {
        this.thickness = 0.0;
      }
      if (initObj.hasOwnProperty('scale_invariant')) {
        this.scale_invariant = initObj.scale_invariant
      }
      else {
        this.scale_invariant = false;
      }
      if (initObj.hasOwnProperty('points')) {
        this.points = initObj.points
      }
      else {
        this.points = [];
      }
      if (initObj.hasOwnProperty('color')) {
        this.color = initObj.color
      }
      else {
        this.color = new Color();
      }
      if (initObj.hasOwnProperty('colors')) {
        this.colors = initObj.colors
      }
      else {
        this.colors = [];
      }
      if (initObj.hasOwnProperty('indices')) {
        this.indices = initObj.indices
      }
      else {
        this.indices = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LinePrimitive
    // Serialize message field [type]
    bufferOffset = _serializer.uint8(obj.type, buffer, bufferOffset);
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose, buffer, bufferOffset);
    // Serialize message field [thickness]
    bufferOffset = _serializer.float64(obj.thickness, buffer, bufferOffset);
    // Serialize message field [scale_invariant]
    bufferOffset = _serializer.bool(obj.scale_invariant, buffer, bufferOffset);
    // Serialize message field [points]
    // Serialize the length for message field [points]
    bufferOffset = _serializer.uint32(obj.points.length, buffer, bufferOffset);
    obj.points.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [color]
    bufferOffset = Color.serialize(obj.color, buffer, bufferOffset);
    // Serialize message field [colors]
    // Serialize the length for message field [colors]
    bufferOffset = _serializer.uint32(obj.colors.length, buffer, bufferOffset);
    obj.colors.forEach((val) => {
      bufferOffset = Color.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [indices]
    bufferOffset = _arraySerializer.uint32(obj.indices, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LinePrimitive
    let len;
    let data = new LinePrimitive(null);
    // Deserialize message field [type]
    data.type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [thickness]
    data.thickness = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [scale_invariant]
    data.scale_invariant = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [points]
    // Deserialize array length for message field [points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.points[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [color]
    data.color = Color.deserialize(buffer, bufferOffset);
    // Deserialize message field [colors]
    // Deserialize array length for message field [colors]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.colors = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.colors[i] = Color.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [indices]
    data.indices = _arrayDeserializer.uint32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 24 * object.points.length;
    length += 32 * object.colors.length;
    length += 4 * object.indices.length;
    return length + 110;
  }

  static datatype() {
    // Returns string type for a message object
    return 'foxglove_msgs/LinePrimitive';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6c2f969386c9a9fb9365fdf2a22d851c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # foxglove_msgs/LinePrimitive
    # A primitive representing a series of points connected by lines
    
    # Generated by https://github.com/foxglove/schemas
    
    # Connected line segments: 0-1, 1-2, ..., (n-1)-n
    uint8 LINE_STRIP=0
    
    # Closed polygon: 0-1, 1-2, ..., (n-1)-n, n-0
    uint8 LINE_LOOP=1
    
    # Individual line segments: 0-1, 2-3, 4-5, ...
    uint8 LINE_LIST=2
    
    # Drawing primitive to use for lines
    uint8 type
    
    # Origin of lines relative to reference frame
    geometry_msgs/Pose pose
    
    # Line thickness
    float64 thickness
    
    # Indicates whether `thickness` is a fixed size in screen pixels (true), or specified in world coordinates and scales with distance from the camera (false)
    bool scale_invariant
    
    # Points along the line
    geometry_msgs/Point[] points
    
    # Solid color to use for the whole line. One of `color` or `colors` must be provided.
    foxglove_msgs/Color color
    
    # Per-point colors (if specified, must have the same length as `points`). One of `color` or `colors` must be provided.
    foxglove_msgs/Color[] colors
    
    # Indices into the `points` and `colors` attribute arrays, which can be used to avoid duplicating attribute data.
    # 
    # If omitted or empty, indexing will not be used. This default behavior is equivalent to specifying [0, 1, ..., N-1] for the indices (where N is the number of `points` provided).
    uint32[] indices
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: foxglove_msgs/Color
    # foxglove_msgs/Color
    # A color in RGBA format
    
    # Generated by https://github.com/foxglove/schemas
    
    # Red value between 0 and 1
    float64 r
    
    # Green value between 0 and 1
    float64 g
    
    # Blue value between 0 and 1
    float64 b
    
    # Alpha value between 0 and 1
    float64 a
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LinePrimitive(null);
    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.Pose.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.Pose()
    }

    if (msg.thickness !== undefined) {
      resolved.thickness = msg.thickness;
    }
    else {
      resolved.thickness = 0.0
    }

    if (msg.scale_invariant !== undefined) {
      resolved.scale_invariant = msg.scale_invariant;
    }
    else {
      resolved.scale_invariant = false
    }

    if (msg.points !== undefined) {
      resolved.points = new Array(msg.points.length);
      for (let i = 0; i < resolved.points.length; ++i) {
        resolved.points[i] = geometry_msgs.msg.Point.Resolve(msg.points[i]);
      }
    }
    else {
      resolved.points = []
    }

    if (msg.color !== undefined) {
      resolved.color = Color.Resolve(msg.color)
    }
    else {
      resolved.color = new Color()
    }

    if (msg.colors !== undefined) {
      resolved.colors = new Array(msg.colors.length);
      for (let i = 0; i < resolved.colors.length; ++i) {
        resolved.colors[i] = Color.Resolve(msg.colors[i]);
      }
    }
    else {
      resolved.colors = []
    }

    if (msg.indices !== undefined) {
      resolved.indices = msg.indices;
    }
    else {
      resolved.indices = []
    }

    return resolved;
    }
};

// Constants for message
LinePrimitive.Constants = {
  LINE_STRIP: 0,
  LINE_LOOP: 1,
  LINE_LIST: 2,
}

module.exports = LinePrimitive;
