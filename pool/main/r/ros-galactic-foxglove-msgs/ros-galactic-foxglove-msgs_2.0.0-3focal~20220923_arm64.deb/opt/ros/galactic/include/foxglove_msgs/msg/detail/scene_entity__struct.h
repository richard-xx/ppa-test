// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from foxglove_msgs:msg/SceneEntity.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__SCENE_ENTITY__STRUCT_H_
#define FOXGLOVE_MSGS__MSG__DETAIL__SCENE_ENTITY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'frame_id'
// Member 'id'
#include "rosidl_runtime_c/string.h"
// Member 'lifetime'
#include "builtin_interfaces/msg/detail/duration__struct.h"
// Member 'metadata'
#include "foxglove_msgs/msg/detail/key_value_pair__struct.h"
// Member 'arrows'
#include "foxglove_msgs/msg/detail/arrow_primitive__struct.h"
// Member 'cubes'
#include "foxglove_msgs/msg/detail/cube_primitive__struct.h"
// Member 'spheres'
#include "foxglove_msgs/msg/detail/sphere_primitive__struct.h"
// Member 'cylinders'
#include "foxglove_msgs/msg/detail/cylinder_primitive__struct.h"
// Member 'lines'
#include "foxglove_msgs/msg/detail/line_primitive__struct.h"
// Member 'triangles'
#include "foxglove_msgs/msg/detail/triangle_list_primitive__struct.h"
// Member 'texts'
#include "foxglove_msgs/msg/detail/text_primitive__struct.h"
// Member 'models'
#include "foxglove_msgs/msg/detail/model_primitive__struct.h"

// Struct defined in msg/SceneEntity in the package foxglove_msgs.
typedef struct foxglove_msgs__msg__SceneEntity
{
  builtin_interfaces__msg__Time timestamp;
  rosidl_runtime_c__String frame_id;
  rosidl_runtime_c__String id;
  builtin_interfaces__msg__Duration lifetime;
  bool frame_locked;
  foxglove_msgs__msg__KeyValuePair__Sequence metadata;
  foxglove_msgs__msg__ArrowPrimitive__Sequence arrows;
  foxglove_msgs__msg__CubePrimitive__Sequence cubes;
  foxglove_msgs__msg__SpherePrimitive__Sequence spheres;
  foxglove_msgs__msg__CylinderPrimitive__Sequence cylinders;
  foxglove_msgs__msg__LinePrimitive__Sequence lines;
  foxglove_msgs__msg__TriangleListPrimitive__Sequence triangles;
  foxglove_msgs__msg__TextPrimitive__Sequence texts;
  foxglove_msgs__msg__ModelPrimitive__Sequence models;
} foxglove_msgs__msg__SceneEntity;

// Struct for a sequence of foxglove_msgs__msg__SceneEntity.
typedef struct foxglove_msgs__msg__SceneEntity__Sequence
{
  foxglove_msgs__msg__SceneEntity * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} foxglove_msgs__msg__SceneEntity__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__SCENE_ENTITY__STRUCT_H_
