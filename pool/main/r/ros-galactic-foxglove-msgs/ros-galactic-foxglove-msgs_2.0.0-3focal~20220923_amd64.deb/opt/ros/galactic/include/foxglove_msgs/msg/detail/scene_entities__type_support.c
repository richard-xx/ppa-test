// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from foxglove_msgs:msg/SceneEntities.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "foxglove_msgs/msg/detail/scene_entities__rosidl_typesupport_introspection_c.h"
#include "foxglove_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "foxglove_msgs/msg/detail/scene_entities__functions.h"
#include "foxglove_msgs/msg/detail/scene_entities__struct.h"


// Include directives for member types
// Member `deletions`
#include "foxglove_msgs/msg/scene_entity_deletion.h"
// Member `deletions`
#include "foxglove_msgs/msg/detail/scene_entity_deletion__rosidl_typesupport_introspection_c.h"
// Member `entities`
#include "foxglove_msgs/msg/scene_entity.h"
// Member `entities`
#include "foxglove_msgs/msg/detail/scene_entity__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  foxglove_msgs__msg__SceneEntities__init(message_memory);
}

void SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_fini_function(void * message_memory)
{
  foxglove_msgs__msg__SceneEntities__fini(message_memory);
}

size_t SceneEntities__rosidl_typesupport_introspection_c__size_function__SceneEntityDeletion__deletions(
  const void * untyped_member)
{
  const foxglove_msgs__msg__SceneEntityDeletion__Sequence * member =
    (const foxglove_msgs__msg__SceneEntityDeletion__Sequence *)(untyped_member);
  return member->size;
}

const void * SceneEntities__rosidl_typesupport_introspection_c__get_const_function__SceneEntityDeletion__deletions(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__SceneEntityDeletion__Sequence * member =
    (const foxglove_msgs__msg__SceneEntityDeletion__Sequence *)(untyped_member);
  return &member->data[index];
}

void * SceneEntities__rosidl_typesupport_introspection_c__get_function__SceneEntityDeletion__deletions(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__SceneEntityDeletion__Sequence * member =
    (foxglove_msgs__msg__SceneEntityDeletion__Sequence *)(untyped_member);
  return &member->data[index];
}

bool SceneEntities__rosidl_typesupport_introspection_c__resize_function__SceneEntityDeletion__deletions(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__SceneEntityDeletion__Sequence * member =
    (foxglove_msgs__msg__SceneEntityDeletion__Sequence *)(untyped_member);
  foxglove_msgs__msg__SceneEntityDeletion__Sequence__fini(member);
  return foxglove_msgs__msg__SceneEntityDeletion__Sequence__init(member, size);
}

size_t SceneEntities__rosidl_typesupport_introspection_c__size_function__SceneEntity__entities(
  const void * untyped_member)
{
  const foxglove_msgs__msg__SceneEntity__Sequence * member =
    (const foxglove_msgs__msg__SceneEntity__Sequence *)(untyped_member);
  return member->size;
}

const void * SceneEntities__rosidl_typesupport_introspection_c__get_const_function__SceneEntity__entities(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__SceneEntity__Sequence * member =
    (const foxglove_msgs__msg__SceneEntity__Sequence *)(untyped_member);
  return &member->data[index];
}

void * SceneEntities__rosidl_typesupport_introspection_c__get_function__SceneEntity__entities(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__SceneEntity__Sequence * member =
    (foxglove_msgs__msg__SceneEntity__Sequence *)(untyped_member);
  return &member->data[index];
}

bool SceneEntities__rosidl_typesupport_introspection_c__resize_function__SceneEntity__entities(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__SceneEntity__Sequence * member =
    (foxglove_msgs__msg__SceneEntity__Sequence *)(untyped_member);
  foxglove_msgs__msg__SceneEntity__Sequence__fini(member);
  return foxglove_msgs__msg__SceneEntity__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_message_member_array[2] = {
  {
    "deletions",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntities, deletions),  // bytes offset in struct
    NULL,  // default value
    SceneEntities__rosidl_typesupport_introspection_c__size_function__SceneEntityDeletion__deletions,  // size() function pointer
    SceneEntities__rosidl_typesupport_introspection_c__get_const_function__SceneEntityDeletion__deletions,  // get_const(index) function pointer
    SceneEntities__rosidl_typesupport_introspection_c__get_function__SceneEntityDeletion__deletions,  // get(index) function pointer
    SceneEntities__rosidl_typesupport_introspection_c__resize_function__SceneEntityDeletion__deletions  // resize(index) function pointer
  },
  {
    "entities",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__SceneEntities, entities),  // bytes offset in struct
    NULL,  // default value
    SceneEntities__rosidl_typesupport_introspection_c__size_function__SceneEntity__entities,  // size() function pointer
    SceneEntities__rosidl_typesupport_introspection_c__get_const_function__SceneEntity__entities,  // get_const(index) function pointer
    SceneEntities__rosidl_typesupport_introspection_c__get_function__SceneEntity__entities,  // get(index) function pointer
    SceneEntities__rosidl_typesupport_introspection_c__resize_function__SceneEntity__entities  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_message_members = {
  "foxglove_msgs__msg",  // message namespace
  "SceneEntities",  // message name
  2,  // number of fields
  sizeof(foxglove_msgs__msg__SceneEntities),
  SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_message_member_array,  // message members
  SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_init_function,  // function to initialize message memory (memory has to be allocated)
  SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_message_type_support_handle = {
  0,
  &SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_foxglove_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, SceneEntities)() {
  SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, SceneEntityDeletion)();
  SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, SceneEntity)();
  if (!SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_message_type_support_handle.typesupport_identifier) {
    SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &SceneEntities__rosidl_typesupport_introspection_c__SceneEntities_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
