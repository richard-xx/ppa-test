// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from foxglove_msgs:msg/LinePrimitive.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "foxglove_msgs/msg/detail/line_primitive__rosidl_typesupport_introspection_c.h"
#include "foxglove_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "foxglove_msgs/msg/detail/line_primitive__functions.h"
#include "foxglove_msgs/msg/detail/line_primitive__struct.h"


// Include directives for member types
// Member `pose`
#include "geometry_msgs/msg/pose.h"
// Member `pose`
#include "geometry_msgs/msg/detail/pose__rosidl_typesupport_introspection_c.h"
// Member `points`
#include "geometry_msgs/msg/point.h"
// Member `points`
#include "geometry_msgs/msg/detail/point__rosidl_typesupport_introspection_c.h"
// Member `color`
// Member `colors`
#include "foxglove_msgs/msg/color.h"
// Member `color`
// Member `colors`
#include "foxglove_msgs/msg/detail/color__rosidl_typesupport_introspection_c.h"
// Member `indices`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  foxglove_msgs__msg__LinePrimitive__init(message_memory);
}

void LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_fini_function(void * message_memory)
{
  foxglove_msgs__msg__LinePrimitive__fini(message_memory);
}

size_t LinePrimitive__rosidl_typesupport_introspection_c__size_function__Point__points(
  const void * untyped_member)
{
  const geometry_msgs__msg__Point__Sequence * member =
    (const geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return member->size;
}

const void * LinePrimitive__rosidl_typesupport_introspection_c__get_const_function__Point__points(
  const void * untyped_member, size_t index)
{
  const geometry_msgs__msg__Point__Sequence * member =
    (const geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return &member->data[index];
}

void * LinePrimitive__rosidl_typesupport_introspection_c__get_function__Point__points(
  void * untyped_member, size_t index)
{
  geometry_msgs__msg__Point__Sequence * member =
    (geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return &member->data[index];
}

bool LinePrimitive__rosidl_typesupport_introspection_c__resize_function__Point__points(
  void * untyped_member, size_t size)
{
  geometry_msgs__msg__Point__Sequence * member =
    (geometry_msgs__msg__Point__Sequence *)(untyped_member);
  geometry_msgs__msg__Point__Sequence__fini(member);
  return geometry_msgs__msg__Point__Sequence__init(member, size);
}

size_t LinePrimitive__rosidl_typesupport_introspection_c__size_function__Color__colors(
  const void * untyped_member)
{
  const foxglove_msgs__msg__Color__Sequence * member =
    (const foxglove_msgs__msg__Color__Sequence *)(untyped_member);
  return member->size;
}

const void * LinePrimitive__rosidl_typesupport_introspection_c__get_const_function__Color__colors(
  const void * untyped_member, size_t index)
{
  const foxglove_msgs__msg__Color__Sequence * member =
    (const foxglove_msgs__msg__Color__Sequence *)(untyped_member);
  return &member->data[index];
}

void * LinePrimitive__rosidl_typesupport_introspection_c__get_function__Color__colors(
  void * untyped_member, size_t index)
{
  foxglove_msgs__msg__Color__Sequence * member =
    (foxglove_msgs__msg__Color__Sequence *)(untyped_member);
  return &member->data[index];
}

bool LinePrimitive__rosidl_typesupport_introspection_c__resize_function__Color__colors(
  void * untyped_member, size_t size)
{
  foxglove_msgs__msg__Color__Sequence * member =
    (foxglove_msgs__msg__Color__Sequence *)(untyped_member);
  foxglove_msgs__msg__Color__Sequence__fini(member);
  return foxglove_msgs__msg__Color__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_member_array[8] = {
  {
    "type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__LinePrimitive, type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "pose",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__LinePrimitive, pose),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "thickness",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__LinePrimitive, thickness),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "scale_invariant",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__LinePrimitive, scale_invariant),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "points",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__LinePrimitive, points),  // bytes offset in struct
    NULL,  // default value
    LinePrimitive__rosidl_typesupport_introspection_c__size_function__Point__points,  // size() function pointer
    LinePrimitive__rosidl_typesupport_introspection_c__get_const_function__Point__points,  // get_const(index) function pointer
    LinePrimitive__rosidl_typesupport_introspection_c__get_function__Point__points,  // get(index) function pointer
    LinePrimitive__rosidl_typesupport_introspection_c__resize_function__Point__points  // resize(index) function pointer
  },
  {
    "color",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__LinePrimitive, color),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "colors",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__LinePrimitive, colors),  // bytes offset in struct
    NULL,  // default value
    LinePrimitive__rosidl_typesupport_introspection_c__size_function__Color__colors,  // size() function pointer
    LinePrimitive__rosidl_typesupport_introspection_c__get_const_function__Color__colors,  // get_const(index) function pointer
    LinePrimitive__rosidl_typesupport_introspection_c__get_function__Color__colors,  // get(index) function pointer
    LinePrimitive__rosidl_typesupport_introspection_c__resize_function__Color__colors  // resize(index) function pointer
  },
  {
    "indices",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(foxglove_msgs__msg__LinePrimitive, indices),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_members = {
  "foxglove_msgs__msg",  // message namespace
  "LinePrimitive",  // message name
  8,  // number of fields
  sizeof(foxglove_msgs__msg__LinePrimitive),
  LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_member_array,  // message members
  LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_init_function,  // function to initialize message memory (memory has to be allocated)
  LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_type_support_handle = {
  0,
  &LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_foxglove_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, LinePrimitive)() {
  LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Pose)();
  LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_member_array[4].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Point)();
  LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_member_array[5].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, Color)();
  LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_member_array[6].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, foxglove_msgs, msg, Color)();
  if (!LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_type_support_handle.typesupport_identifier) {
    LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &LinePrimitive__rosidl_typesupport_introspection_c__LinePrimitive_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
