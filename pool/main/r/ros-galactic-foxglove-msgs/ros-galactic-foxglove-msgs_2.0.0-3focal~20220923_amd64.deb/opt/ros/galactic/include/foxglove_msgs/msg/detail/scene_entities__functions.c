// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from foxglove_msgs:msg/SceneEntities.idl
// generated code does not contain a copyright notice
#include "foxglove_msgs/msg/detail/scene_entities__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `deletions`
#include "foxglove_msgs/msg/detail/scene_entity_deletion__functions.h"
// Member `entities`
#include "foxglove_msgs/msg/detail/scene_entity__functions.h"

bool
foxglove_msgs__msg__SceneEntities__init(foxglove_msgs__msg__SceneEntities * msg)
{
  if (!msg) {
    return false;
  }
  // deletions
  if (!foxglove_msgs__msg__SceneEntityDeletion__Sequence__init(&msg->deletions, 0)) {
    foxglove_msgs__msg__SceneEntities__fini(msg);
    return false;
  }
  // entities
  if (!foxglove_msgs__msg__SceneEntity__Sequence__init(&msg->entities, 0)) {
    foxglove_msgs__msg__SceneEntities__fini(msg);
    return false;
  }
  return true;
}

void
foxglove_msgs__msg__SceneEntities__fini(foxglove_msgs__msg__SceneEntities * msg)
{
  if (!msg) {
    return;
  }
  // deletions
  foxglove_msgs__msg__SceneEntityDeletion__Sequence__fini(&msg->deletions);
  // entities
  foxglove_msgs__msg__SceneEntity__Sequence__fini(&msg->entities);
}

bool
foxglove_msgs__msg__SceneEntities__are_equal(const foxglove_msgs__msg__SceneEntities * lhs, const foxglove_msgs__msg__SceneEntities * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // deletions
  if (!foxglove_msgs__msg__SceneEntityDeletion__Sequence__are_equal(
      &(lhs->deletions), &(rhs->deletions)))
  {
    return false;
  }
  // entities
  if (!foxglove_msgs__msg__SceneEntity__Sequence__are_equal(
      &(lhs->entities), &(rhs->entities)))
  {
    return false;
  }
  return true;
}

bool
foxglove_msgs__msg__SceneEntities__copy(
  const foxglove_msgs__msg__SceneEntities * input,
  foxglove_msgs__msg__SceneEntities * output)
{
  if (!input || !output) {
    return false;
  }
  // deletions
  if (!foxglove_msgs__msg__SceneEntityDeletion__Sequence__copy(
      &(input->deletions), &(output->deletions)))
  {
    return false;
  }
  // entities
  if (!foxglove_msgs__msg__SceneEntity__Sequence__copy(
      &(input->entities), &(output->entities)))
  {
    return false;
  }
  return true;
}

foxglove_msgs__msg__SceneEntities *
foxglove_msgs__msg__SceneEntities__create()
{
  foxglove_msgs__msg__SceneEntities * msg = (foxglove_msgs__msg__SceneEntities *)malloc(sizeof(foxglove_msgs__msg__SceneEntities));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(foxglove_msgs__msg__SceneEntities));
  bool success = foxglove_msgs__msg__SceneEntities__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
foxglove_msgs__msg__SceneEntities__destroy(foxglove_msgs__msg__SceneEntities * msg)
{
  if (msg) {
    foxglove_msgs__msg__SceneEntities__fini(msg);
  }
  free(msg);
}


bool
foxglove_msgs__msg__SceneEntities__Sequence__init(foxglove_msgs__msg__SceneEntities__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  foxglove_msgs__msg__SceneEntities * data = NULL;
  if (size) {
    data = (foxglove_msgs__msg__SceneEntities *)calloc(size, sizeof(foxglove_msgs__msg__SceneEntities));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = foxglove_msgs__msg__SceneEntities__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        foxglove_msgs__msg__SceneEntities__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
foxglove_msgs__msg__SceneEntities__Sequence__fini(foxglove_msgs__msg__SceneEntities__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      foxglove_msgs__msg__SceneEntities__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

foxglove_msgs__msg__SceneEntities__Sequence *
foxglove_msgs__msg__SceneEntities__Sequence__create(size_t size)
{
  foxglove_msgs__msg__SceneEntities__Sequence * array = (foxglove_msgs__msg__SceneEntities__Sequence *)malloc(sizeof(foxglove_msgs__msg__SceneEntities__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = foxglove_msgs__msg__SceneEntities__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
foxglove_msgs__msg__SceneEntities__Sequence__destroy(foxglove_msgs__msg__SceneEntities__Sequence * array)
{
  if (array) {
    foxglove_msgs__msg__SceneEntities__Sequence__fini(array);
  }
  free(array);
}

bool
foxglove_msgs__msg__SceneEntities__Sequence__are_equal(const foxglove_msgs__msg__SceneEntities__Sequence * lhs, const foxglove_msgs__msg__SceneEntities__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!foxglove_msgs__msg__SceneEntities__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
foxglove_msgs__msg__SceneEntities__Sequence__copy(
  const foxglove_msgs__msg__SceneEntities__Sequence * input,
  foxglove_msgs__msg__SceneEntities__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(foxglove_msgs__msg__SceneEntities);
    foxglove_msgs__msg__SceneEntities * data =
      (foxglove_msgs__msg__SceneEntities *)realloc(output->data, allocation_size);
    if (!data) {
      return false;
    }
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!foxglove_msgs__msg__SceneEntities__init(&data[i])) {
        /* free currently allocated and return false */
        for (; i-- > output->capacity; ) {
          foxglove_msgs__msg__SceneEntities__fini(&data[i]);
        }
        free(data);
        return false;
      }
    }
    output->data = data;
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!foxglove_msgs__msg__SceneEntities__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
