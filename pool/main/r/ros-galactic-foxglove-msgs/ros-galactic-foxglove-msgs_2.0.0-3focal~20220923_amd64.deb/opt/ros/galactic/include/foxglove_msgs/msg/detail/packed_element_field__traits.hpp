// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from foxglove_msgs:msg/PackedElementField.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__PACKED_ELEMENT_FIELD__TRAITS_HPP_
#define FOXGLOVE_MSGS__MSG__DETAIL__PACKED_ELEMENT_FIELD__TRAITS_HPP_

#include "foxglove_msgs/msg/detail/packed_element_field__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

namespace rosidl_generator_traits
{

inline void to_yaml(
  const foxglove_msgs::msg::PackedElementField & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "name: ";
    value_to_yaml(msg.name, out);
    out << "\n";
  }

  // member: offset
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "offset: ";
    value_to_yaml(msg.offset, out);
    out << "\n";
  }

  // member: type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "type: ";
    value_to_yaml(msg.type, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const foxglove_msgs::msg::PackedElementField & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<foxglove_msgs::msg::PackedElementField>()
{
  return "foxglove_msgs::msg::PackedElementField";
}

template<>
inline const char * name<foxglove_msgs::msg::PackedElementField>()
{
  return "foxglove_msgs/msg/PackedElementField";
}

template<>
struct has_fixed_size<foxglove_msgs::msg::PackedElementField>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<foxglove_msgs::msg::PackedElementField>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<foxglove_msgs::msg::PackedElementField>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__PACKED_ELEMENT_FIELD__TRAITS_HPP_
