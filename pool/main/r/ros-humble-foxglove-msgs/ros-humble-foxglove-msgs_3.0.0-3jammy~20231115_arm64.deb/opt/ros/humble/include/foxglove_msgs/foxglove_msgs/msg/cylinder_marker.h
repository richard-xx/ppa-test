// generated from rosidl_generator_c/resource/idl.h.em
// with input from foxglove_msgs:msg/CylinderMarker.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__CYLINDER_MARKER_H_
#define FOXGLOVE_MSGS__MSG__CYLINDER_MARKER_H_

#include "foxglove_msgs/msg/detail/cylinder_marker__struct.h"
#include "foxglove_msgs/msg/detail/cylinder_marker__functions.h"
#include "foxglove_msgs/msg/detail/cylinder_marker__type_support.h"

#endif  // FOXGLOVE_MSGS__MSG__CYLINDER_MARKER_H_
