// generated from rosidl_generator_c/resource/idl.h.em
// with input from foxglove_msgs:msg/CircleAnnotation.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__CIRCLE_ANNOTATION_H_
#define FOXGLOVE_MSGS__MSG__CIRCLE_ANNOTATION_H_

#include "foxglove_msgs/msg/detail/circle_annotation__struct.h"
#include "foxglove_msgs/msg/detail/circle_annotation__functions.h"
#include "foxglove_msgs/msg/detail/circle_annotation__type_support.h"

#endif  // FOXGLOVE_MSGS__MSG__CIRCLE_ANNOTATION_H_
