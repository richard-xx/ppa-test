// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__CONE_PRIMITIVE_HPP_
#define FOXGLOVE_MSGS__MSG__CONE_PRIMITIVE_HPP_

#include "foxglove_msgs/msg/detail/cone_primitive__struct.hpp"
#include "foxglove_msgs/msg/detail/cone_primitive__builder.hpp"
#include "foxglove_msgs/msg/detail/cone_primitive__traits.hpp"

#endif  // FOXGLOVE_MSGS__MSG__CONE_PRIMITIVE_HPP_
