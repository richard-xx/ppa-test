// generated from rosidl_generator_c/resource/idl.h.em
// with input from foxglove_msgs:msg/ArrowMarker.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__ARROW_MARKER_H_
#define FOXGLOVE_MSGS__MSG__ARROW_MARKER_H_

#include "foxglove_msgs/msg/detail/arrow_marker__struct.h"
#include "foxglove_msgs/msg/detail/arrow_marker__functions.h"
#include "foxglove_msgs/msg/detail/arrow_marker__type_support.h"

#endif  // FOXGLOVE_MSGS__MSG__ARROW_MARKER_H_
