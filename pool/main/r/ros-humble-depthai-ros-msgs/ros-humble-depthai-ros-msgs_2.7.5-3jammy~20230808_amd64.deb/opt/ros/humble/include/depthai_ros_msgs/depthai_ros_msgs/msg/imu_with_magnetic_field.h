// generated from rosidl_generator_c/resource/idl.h.em
// with input from depthai_ros_msgs:msg/ImuWithMagneticField.idl
// generated code does not contain a copyright notice

#ifndef DEPTHAI_ROS_MSGS__MSG__IMU_WITH_MAGNETIC_FIELD_H_
#define DEPTHAI_ROS_MSGS__MSG__IMU_WITH_MAGNETIC_FIELD_H_

#include "depthai_ros_msgs/msg/detail/imu_with_magnetic_field__struct.h"
#include "depthai_ros_msgs/msg/detail/imu_with_magnetic_field__functions.h"
#include "depthai_ros_msgs/msg/detail/imu_with_magnetic_field__type_support.h"

#endif  // DEPTHAI_ROS_MSGS__MSG__IMU_WITH_MAGNETIC_FIELD_H_
