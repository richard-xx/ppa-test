// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DEPTHAI_ROS_MSGS__MSG__IMU_WITH_MAGNETIC_FIELD_HPP_
#define DEPTHAI_ROS_MSGS__MSG__IMU_WITH_MAGNETIC_FIELD_HPP_

#include "depthai_ros_msgs/msg/detail/imu_with_magnetic_field__struct.hpp"
#include "depthai_ros_msgs/msg/detail/imu_with_magnetic_field__builder.hpp"
#include "depthai_ros_msgs/msg/detail/imu_with_magnetic_field__traits.hpp"

#endif  // DEPTHAI_ROS_MSGS__MSG__IMU_WITH_MAGNETIC_FIELD_HPP_
