// generated from rosidl_generator_c/resource/idl.h.em
// with input from depthai_ros_msgs:srv/TriggerNamed.idl
// generated code does not contain a copyright notice

#ifndef DEPTHAI_ROS_MSGS__SRV__TRIGGER_NAMED_H_
#define DEPTHAI_ROS_MSGS__SRV__TRIGGER_NAMED_H_

#include "depthai_ros_msgs/srv/detail/trigger_named__struct.h"
#include "depthai_ros_msgs/srv/detail/trigger_named__functions.h"
#include "depthai_ros_msgs/srv/detail/trigger_named__type_support.h"

#endif  // DEPTHAI_ROS_MSGS__SRV__TRIGGER_NAMED_H_
