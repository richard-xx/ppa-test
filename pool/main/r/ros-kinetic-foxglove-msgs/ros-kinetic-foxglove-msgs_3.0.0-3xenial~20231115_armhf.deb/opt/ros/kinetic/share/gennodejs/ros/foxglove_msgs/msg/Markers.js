// Auto-generated. Do not edit!

// (in-package foxglove_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let MarkerDeletion = require('./MarkerDeletion.js');
let ArrowMarker = require('./ArrowMarker.js');
let CubeListMarker = require('./CubeListMarker.js');
let SphereListMarker = require('./SphereListMarker.js');
let ConeListMarker = require('./ConeListMarker.js');
let LineMarker = require('./LineMarker.js');
let TriangleListMarker = require('./TriangleListMarker.js');
let TextMarker = require('./TextMarker.js');
let ModelMarker = require('./ModelMarker.js');

//-----------------------------------------------------------

class Markers {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.deletions = null;
      this.arrows = null;
      this.cubes = null;
      this.spheres = null;
      this.cones = null;
      this.lines = null;
      this.triangles = null;
      this.texts = null;
      this.models = null;
    }
    else {
      if (initObj.hasOwnProperty('deletions')) {
        this.deletions = initObj.deletions
      }
      else {
        this.deletions = [];
      }
      if (initObj.hasOwnProperty('arrows')) {
        this.arrows = initObj.arrows
      }
      else {
        this.arrows = [];
      }
      if (initObj.hasOwnProperty('cubes')) {
        this.cubes = initObj.cubes
      }
      else {
        this.cubes = [];
      }
      if (initObj.hasOwnProperty('spheres')) {
        this.spheres = initObj.spheres
      }
      else {
        this.spheres = [];
      }
      if (initObj.hasOwnProperty('cones')) {
        this.cones = initObj.cones
      }
      else {
        this.cones = [];
      }
      if (initObj.hasOwnProperty('lines')) {
        this.lines = initObj.lines
      }
      else {
        this.lines = [];
      }
      if (initObj.hasOwnProperty('triangles')) {
        this.triangles = initObj.triangles
      }
      else {
        this.triangles = [];
      }
      if (initObj.hasOwnProperty('texts')) {
        this.texts = initObj.texts
      }
      else {
        this.texts = [];
      }
      if (initObj.hasOwnProperty('models')) {
        this.models = initObj.models
      }
      else {
        this.models = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Markers
    // Serialize message field [deletions]
    // Serialize the length for message field [deletions]
    bufferOffset = _serializer.uint32(obj.deletions.length, buffer, bufferOffset);
    obj.deletions.forEach((val) => {
      bufferOffset = MarkerDeletion.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [arrows]
    // Serialize the length for message field [arrows]
    bufferOffset = _serializer.uint32(obj.arrows.length, buffer, bufferOffset);
    obj.arrows.forEach((val) => {
      bufferOffset = ArrowMarker.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [cubes]
    // Serialize the length for message field [cubes]
    bufferOffset = _serializer.uint32(obj.cubes.length, buffer, bufferOffset);
    obj.cubes.forEach((val) => {
      bufferOffset = CubeListMarker.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [spheres]
    // Serialize the length for message field [spheres]
    bufferOffset = _serializer.uint32(obj.spheres.length, buffer, bufferOffset);
    obj.spheres.forEach((val) => {
      bufferOffset = SphereListMarker.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [cones]
    // Serialize the length for message field [cones]
    bufferOffset = _serializer.uint32(obj.cones.length, buffer, bufferOffset);
    obj.cones.forEach((val) => {
      bufferOffset = ConeListMarker.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [lines]
    // Serialize the length for message field [lines]
    bufferOffset = _serializer.uint32(obj.lines.length, buffer, bufferOffset);
    obj.lines.forEach((val) => {
      bufferOffset = LineMarker.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [triangles]
    // Serialize the length for message field [triangles]
    bufferOffset = _serializer.uint32(obj.triangles.length, buffer, bufferOffset);
    obj.triangles.forEach((val) => {
      bufferOffset = TriangleListMarker.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [texts]
    // Serialize the length for message field [texts]
    bufferOffset = _serializer.uint32(obj.texts.length, buffer, bufferOffset);
    obj.texts.forEach((val) => {
      bufferOffset = TextMarker.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [models]
    // Serialize the length for message field [models]
    bufferOffset = _serializer.uint32(obj.models.length, buffer, bufferOffset);
    obj.models.forEach((val) => {
      bufferOffset = ModelMarker.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Markers
    let len;
    let data = new Markers(null);
    // Deserialize message field [deletions]
    // Deserialize array length for message field [deletions]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.deletions = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.deletions[i] = MarkerDeletion.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [arrows]
    // Deserialize array length for message field [arrows]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.arrows = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.arrows[i] = ArrowMarker.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [cubes]
    // Deserialize array length for message field [cubes]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.cubes = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.cubes[i] = CubeListMarker.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [spheres]
    // Deserialize array length for message field [spheres]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.spheres = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.spheres[i] = SphereListMarker.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [cones]
    // Deserialize array length for message field [cones]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.cones = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.cones[i] = ConeListMarker.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [lines]
    // Deserialize array length for message field [lines]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.lines = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.lines[i] = LineMarker.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [triangles]
    // Deserialize array length for message field [triangles]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.triangles = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.triangles[i] = TriangleListMarker.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [texts]
    // Deserialize array length for message field [texts]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.texts = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.texts[i] = TextMarker.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [models]
    // Deserialize array length for message field [models]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.models = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.models[i] = ModelMarker.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.deletions.forEach((val) => {
      length += MarkerDeletion.getMessageSize(val);
    });
    length += 120 * object.arrows.length;
    object.cubes.forEach((val) => {
      length += CubeListMarker.getMessageSize(val);
    });
    object.spheres.forEach((val) => {
      length += SphereListMarker.getMessageSize(val);
    });
    object.cones.forEach((val) => {
      length += ConeListMarker.getMessageSize(val);
    });
    object.lines.forEach((val) => {
      length += LineMarker.getMessageSize(val);
    });
    object.triangles.forEach((val) => {
      length += TriangleListMarker.getMessageSize(val);
    });
    object.texts.forEach((val) => {
      length += TextMarker.getMessageSize(val);
    });
    object.models.forEach((val) => {
      length += ModelMarker.getMessageSize(val);
    });
    return length + 36;
  }

  static datatype() {
    // Returns string type for a message object
    return 'foxglove_msgs/Markers';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7adad93502db1b37c29f6a3eafcc7dda';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # foxglove_msgs/Markers
    # A list of any number or type of markers
    
    # Generated by https://github.com/foxglove/schemas
    
    # Marker deletion actions
    foxglove_msgs/MarkerDeletion[] deletions
    
    # Arrow markers
    foxglove_msgs/ArrowMarker[] arrows
    
    # Cube list markers
    foxglove_msgs/CubeListMarker[] cubes
    
    # Sphere list markers
    foxglove_msgs/SphereListMarker[] spheres
    
    # Cone list markers
    foxglove_msgs/ConeListMarker[] cones
    
    # Line markers
    foxglove_msgs/LineMarker[] lines
    
    # Triangle list markers
    foxglove_msgs/TriangleListMarker[] triangles
    
    # Text markers
    foxglove_msgs/TextMarker[] texts
    
    # Model markers
    foxglove_msgs/ModelMarker[] models
    
    ================================================================================
    MSG: foxglove_msgs/MarkerDeletion
    # foxglove_msgs/MarkerDeletion
    # Command to remove previously published markers
    
    # Generated by https://github.com/foxglove/schemas
    
    # Timestamp of the marker. Only matching markers earlier than this timestamp will be deleted.
    time timestamp
    
    uint8 MATCHING_ID=0
    uint8 ALL=1
    
    # Type of deletion action to perform
    uint8 type
    
    # Numeric identifier which must match if `kind` is `MATCHING_ID`.
    string id
    
    ================================================================================
    MSG: foxglove_msgs/ArrowMarker
    # foxglove_msgs/ArrowMarker
    # A marker representing an arrow
    
    # Generated by https://github.com/foxglove/schemas
    
    # Position of the arrow's tail and orientation of the arrow. Identity orientation means the arrow points in the +x direction.
    geometry_msgs/Pose pose
    
    # Length of the arrow
    float64 length
    
    # Diameter of the arrow shaft
    float64 shaft_diameter
    
    # Diameter of the arrow head
    float64 head_diameter
    
    # Length of the arrow head
    float64 head_length
    
    # Color of the arrow
    foxglove_msgs/Color color
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: foxglove_msgs/Color
    # foxglove_msgs/Color
    # A color in RGBA format
    
    # Generated by https://github.com/foxglove/schemas
    
    # Red value between 0 and 1
    float64 r
    
    # Green value between 0 and 1
    float64 g
    
    # Blue value between 0 and 1
    float64 b
    
    # Alpha value between 0 and 1
    float64 a
    
    ================================================================================
    MSG: foxglove_msgs/CubeListMarker
    # foxglove_msgs/CubeListMarker
    # A marker representing a list of cubes or rectangular prisms
    
    # Generated by https://github.com/foxglove/schemas
    
    # Timestamp of the marker
    time timestamp
    
    # Frame of reference
    string frame_id
    
    # Identifier for the marker. A marker will replace any prior marker on the same topic with the same `id`.
    string id
    
    # Length of time (relative to `timestamp`) after which the marker should be automatically removed. Zero value indicates the marker should remain visible until it is replaced or deleted.
    duration lifetime
    
    # Whether the marker should keep its location in the fixed frame (false) or follow the frame specified in `frame_id` as it moves relative to the fixed frame (true)
    bool frame_locked
    
    # Additional user-provided metadata associated with the marker. Keys must be unique.
    foxglove_msgs/KeyValuePair[] metadata
    
    # Attributes of each cube
    foxglove_msgs/CubeAttributes[] attributes
    
    ================================================================================
    MSG: foxglove_msgs/KeyValuePair
    # foxglove_msgs/KeyValuePair
    # A key with its associated value
    
    # Generated by https://github.com/foxglove/schemas
    
    # Key
    string key
    
    # Value
    string value
    
    ================================================================================
    MSG: foxglove_msgs/CubeAttributes
    # foxglove_msgs/CubeAttributes
    # Data specifying the visual appearance of a cube or rectangular prism
    
    # Generated by https://github.com/foxglove/schemas
    
    # Position of the center of the cube and orientation of the cube
    geometry_msgs/Pose pose
    
    # Size of the cube along each axis
    geometry_msgs/Vector3 size
    
    # Color of the arrow
    foxglove_msgs/Color color
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    ================================================================================
    MSG: foxglove_msgs/SphereListMarker
    # foxglove_msgs/SphereListMarker
    # A marker representing a list of spheres or ellipsoids
    
    # Generated by https://github.com/foxglove/schemas
    
    # Timestamp of the marker
    time timestamp
    
    # Frame of reference
    string frame_id
    
    # Identifier for the marker. A marker will replace any prior marker on the same topic with the same `id`.
    string id
    
    # Length of time (relative to `timestamp`) after which the marker should be automatically removed. Zero value indicates the marker should remain visible until it is replaced or deleted.
    duration lifetime
    
    # Whether the marker should keep its location in the fixed frame (false) or follow the frame specified in `frame_id` as it moves relative to the fixed frame (true)
    bool frame_locked
    
    # Additional user-provided metadata associated with the marker. Keys must be unique.
    foxglove_msgs/KeyValuePair[] metadata
    
    # Attributes of each sphere
    foxglove_msgs/SphereAttributes[] attributes
    
    ================================================================================
    MSG: foxglove_msgs/SphereAttributes
    # foxglove_msgs/SphereAttributes
    # Data specifying the visual appearance of a sphere or ellipsoid
    
    # Generated by https://github.com/foxglove/schemas
    
    # Position of the center of the sphere and orientation of the sphere
    geometry_msgs/Pose pose
    
    # Size (diameter) of the sphere along each axis
    geometry_msgs/Vector3 size
    
    # Color of the sphere
    foxglove_msgs/Color color
    
    ================================================================================
    MSG: foxglove_msgs/ConeListMarker
    # foxglove_msgs/ConeListMarker
    # A marker representing a list of possibly truncated, possibly elliptic cones or cylinders
    
    # Generated by https://github.com/foxglove/schemas
    
    # Timestamp of the marker
    time timestamp
    
    # Frame of reference
    string frame_id
    
    # Identifier for the marker. A marker will replace any prior marker on the same topic with the same `id`.
    string id
    
    # Length of time (relative to `timestamp`) after which the marker should be automatically removed. Zero value indicates the marker should remain visible until it is replaced or deleted.
    duration lifetime
    
    # Whether the marker should keep its location in the fixed frame (false) or follow the frame specified in `frame_id` as it moves relative to the fixed frame (true)
    bool frame_locked
    
    # Additional user-provided metadata associated with the marker. Keys must be unique.
    foxglove_msgs/KeyValuePair[] metadata
    
    # Attributes of each cone
    foxglove_msgs/ConeAttributes[] attributes
    
    ================================================================================
    MSG: foxglove_msgs/ConeAttributes
    # foxglove_msgs/ConeAttributes
    # Data specifying the visual appearance of a possibly truncated, possibly elliptic cone or cylinder
    
    # Generated by https://github.com/foxglove/schemas
    
    # Position of the center of the cone and orientation of the cone. The flat face(s) are perpendicular to the z-axis.
    geometry_msgs/Pose pose
    
    # Size of the cone's bounding box
    geometry_msgs/Vector3 size
    
    # 0-1, size of the cone's bottom face (min z) relative to the bottom of the bounding box
    float64 bottom_scale
    
    # 0-1, size of the cone's top face (max z) relative to the top of the bounding box
    float64 top_scale
    
    # Color of the cone
    foxglove_msgs/Color color
    
    ================================================================================
    MSG: foxglove_msgs/LineMarker
    # foxglove_msgs/LineMarker
    # A marker representing a series of points connected by lines
    
    # Generated by https://github.com/foxglove/schemas
    
    # 0-1, 1-2, ..., (n-1)-n
    uint8 LINE_STRIP=0
    
    # 0-1, 1-2, ..., (n-1)-n, n-0
    uint8 LINE_LOOP=1
    
    # 0-1, 2-3, 4-5, ...
    uint8 LINE_LIST=2
    
    # Drawing primitive to use for lines
    uint8 type
    
    # Origin of lines relative to reference frame
    geometry_msgs/Pose pose
    
    # Line thickness
    float64 thickness
    
    # Indicates whether `thickness` is a fixed size in screen pixels (true), or specified in world coordinates and scales with distance from the camera (false)
    bool scale_invariant
    
    # Points along the line
    geometry_msgs/Point[] points
    
    # Solid color to use for the whole line. One of `color` or `colors` must be provided.
    foxglove_msgs/Color color
    
    # Per-point colors (if specified, must have the same length as `points`). One of `color` or `colors` must be provided.
    foxglove_msgs/Color[] colors
    
    # Indices into the `points` and `colors` attribute arrays, which can be used to avoid duplicating attribute data.
    # 
    # If omitted or empty, indexing will not be used. This default behavior is equivalent to specifying [0, 1, ..., N-1] for the indices (where N is the number of `points` provided).
    uint32[] indices
    
    ================================================================================
    MSG: foxglove_msgs/TriangleListMarker
    # foxglove_msgs/TriangleListMarker
    # A marker representing a set of triangles or a surface tiled by triangles
    
    # Generated by https://github.com/foxglove/schemas
    
    # Origin of triangles relative to reference frame
    geometry_msgs/Pose pose
    
    # Vertices to use for triangles, interpreted as a list of triples (0-1-2, 3-4-5, ...)
    geometry_msgs/Point[] points
    
    # Solid color to use for the whole shape. One of `color` or `colors` must be provided.
    foxglove_msgs/Color color
    
    # Per-vertex colors (if specified, must have the same length as `points`). One of `color` or `colors` must be provided.
    foxglove_msgs/Color[] colors
    
    # Indices into the `points` and `colors` attribute arrays, which can be used to avoid duplicating attribute data.
    # 
    # If omitted or empty, indexing will not be used. This default behavior is equivalent to specifying [0, 1, ..., N-1] for the indices (where N is the number of `points` provided).
    uint32[] indices
    
    ================================================================================
    MSG: foxglove_msgs/TextMarker
    # foxglove_msgs/TextMarker
    # A marker representing a text label
    
    # Generated by https://github.com/foxglove/schemas
    
    # Position of the center of the text box and orientation of the text. Identity orientation means the text is oriented in the xy-plane and flows from -x to +x.
    geometry_msgs/Pose pose
    
    # Whether the text should respect `pose.orientation` (false) or always face the camera (true)
    bool billboard
    
    # Font size (height of one line of text)
    float64 font_size
    
    # Indicates whether `font_size` is a fixed size in screen pixels (true), or specified in world coordinates and scales with distance from the camera (false)
    bool scale_invariant
    
    # Color of the text
    foxglove_msgs/Color color
    
    # Text
    string text
    
    ================================================================================
    MSG: foxglove_msgs/ModelMarker
    # foxglove_msgs/ModelMarker
    # A marker representing a 3D model
    
    # Generated by https://github.com/foxglove/schemas
    
    # Origin of model relative to reference frame
    geometry_msgs/Pose pose
    
    # Scale factor to apply to the model along each axis
    geometry_msgs/Vector3 scale
    
    # Solid color to use for the whole model. If `use_embedded_materials` is true, this color is blended on top of the embedded material color.
    foxglove_msgs/Color color
    
    # Whether to use materials embedded in the model, or only the `color`
    bool use_embedded_materials
    
    # URL pointing to model file. Either `url` or `mime_type` and `data` should be provided.
    string url
    
    # MIME type of embedded model (e.g. `model/gltf-binary`). Either `url` or `mime_type` and `data` should be provided.
    string mime_type
    
    # Embedded model. Either `url` or `mime_type` and `data` should be provided.
    uint8[] data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Markers(null);
    if (msg.deletions !== undefined) {
      resolved.deletions = new Array(msg.deletions.length);
      for (let i = 0; i < resolved.deletions.length; ++i) {
        resolved.deletions[i] = MarkerDeletion.Resolve(msg.deletions[i]);
      }
    }
    else {
      resolved.deletions = []
    }

    if (msg.arrows !== undefined) {
      resolved.arrows = new Array(msg.arrows.length);
      for (let i = 0; i < resolved.arrows.length; ++i) {
        resolved.arrows[i] = ArrowMarker.Resolve(msg.arrows[i]);
      }
    }
    else {
      resolved.arrows = []
    }

    if (msg.cubes !== undefined) {
      resolved.cubes = new Array(msg.cubes.length);
      for (let i = 0; i < resolved.cubes.length; ++i) {
        resolved.cubes[i] = CubeListMarker.Resolve(msg.cubes[i]);
      }
    }
    else {
      resolved.cubes = []
    }

    if (msg.spheres !== undefined) {
      resolved.spheres = new Array(msg.spheres.length);
      for (let i = 0; i < resolved.spheres.length; ++i) {
        resolved.spheres[i] = SphereListMarker.Resolve(msg.spheres[i]);
      }
    }
    else {
      resolved.spheres = []
    }

    if (msg.cones !== undefined) {
      resolved.cones = new Array(msg.cones.length);
      for (let i = 0; i < resolved.cones.length; ++i) {
        resolved.cones[i] = ConeListMarker.Resolve(msg.cones[i]);
      }
    }
    else {
      resolved.cones = []
    }

    if (msg.lines !== undefined) {
      resolved.lines = new Array(msg.lines.length);
      for (let i = 0; i < resolved.lines.length; ++i) {
        resolved.lines[i] = LineMarker.Resolve(msg.lines[i]);
      }
    }
    else {
      resolved.lines = []
    }

    if (msg.triangles !== undefined) {
      resolved.triangles = new Array(msg.triangles.length);
      for (let i = 0; i < resolved.triangles.length; ++i) {
        resolved.triangles[i] = TriangleListMarker.Resolve(msg.triangles[i]);
      }
    }
    else {
      resolved.triangles = []
    }

    if (msg.texts !== undefined) {
      resolved.texts = new Array(msg.texts.length);
      for (let i = 0; i < resolved.texts.length; ++i) {
        resolved.texts[i] = TextMarker.Resolve(msg.texts[i]);
      }
    }
    else {
      resolved.texts = []
    }

    if (msg.models !== undefined) {
      resolved.models = new Array(msg.models.length);
      for (let i = 0; i < resolved.models.length; ++i) {
        resolved.models[i] = ModelMarker.Resolve(msg.models[i]);
      }
    }
    else {
      resolved.models = []
    }

    return resolved;
    }
};

module.exports = Markers;
