// Auto-generated. Do not edit!

// (in-package foxglove_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Vector2 = require('./Vector2.js');
let PackedElementField = require('./PackedElementField.js');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class Grid {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.frame_id = null;
      this.pose = null;
      this.column_count = null;
      this.cell_size = null;
      this.row_stride = null;
      this.cell_stride = null;
      this.fields = null;
      this.data = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('frame_id')) {
        this.frame_id = initObj.frame_id
      }
      else {
        this.frame_id = '';
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('column_count')) {
        this.column_count = initObj.column_count
      }
      else {
        this.column_count = 0;
      }
      if (initObj.hasOwnProperty('cell_size')) {
        this.cell_size = initObj.cell_size
      }
      else {
        this.cell_size = new Vector2();
      }
      if (initObj.hasOwnProperty('row_stride')) {
        this.row_stride = initObj.row_stride
      }
      else {
        this.row_stride = 0;
      }
      if (initObj.hasOwnProperty('cell_stride')) {
        this.cell_stride = initObj.cell_stride
      }
      else {
        this.cell_stride = 0;
      }
      if (initObj.hasOwnProperty('fields')) {
        this.fields = initObj.fields
      }
      else {
        this.fields = [];
      }
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Grid
    // Serialize message field [timestamp]
    bufferOffset = _serializer.time(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [frame_id]
    bufferOffset = _serializer.string(obj.frame_id, buffer, bufferOffset);
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose, buffer, bufferOffset);
    // Serialize message field [column_count]
    bufferOffset = _serializer.uint32(obj.column_count, buffer, bufferOffset);
    // Serialize message field [cell_size]
    bufferOffset = Vector2.serialize(obj.cell_size, buffer, bufferOffset);
    // Serialize message field [row_stride]
    bufferOffset = _serializer.uint32(obj.row_stride, buffer, bufferOffset);
    // Serialize message field [cell_stride]
    bufferOffset = _serializer.uint32(obj.cell_stride, buffer, bufferOffset);
    // Serialize message field [fields]
    // Serialize the length for message field [fields]
    bufferOffset = _serializer.uint32(obj.fields.length, buffer, bufferOffset);
    obj.fields.forEach((val) => {
      bufferOffset = PackedElementField.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [data]
    bufferOffset = _arraySerializer.uint8(obj.data, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Grid
    let len;
    let data = new Grid(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [frame_id]
    data.frame_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [column_count]
    data.column_count = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [cell_size]
    data.cell_size = Vector2.deserialize(buffer, bufferOffset);
    // Deserialize message field [row_stride]
    data.row_stride = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [cell_stride]
    data.cell_stride = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [fields]
    // Deserialize array length for message field [fields]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.fields = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.fields[i] = PackedElementField.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [data]
    data.data = _arrayDeserializer.uint8(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.frame_id.length;
    object.fields.forEach((val) => {
      length += PackedElementField.getMessageSize(val);
    });
    length += object.data.length;
    return length + 104;
  }

  static datatype() {
    // Returns string type for a message object
    return 'foxglove_msgs/Grid';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ff812efab6fae28f163999277c175522';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # foxglove_msgs/Grid
    # A 2D grid of data
    
    # Generated by https://github.com/foxglove/schemas
    
    # Timestamp of grid
    time timestamp
    
    # Frame of reference
    string frame_id
    
    # Origin of grid's corner relative to frame of reference; grid is positioned in the x-y plane relative to this origin
    geometry_msgs/Pose pose
    
    # Number of grid columns
    uint32 column_count
    
    # Size of single grid cell along x and y axes, relative to `pose`
    foxglove_msgs/Vector2 cell_size
    
    # Number of bytes between rows in `data`
    uint32 row_stride
    
    # Number of bytes between cells within a row in `data`
    uint32 cell_stride
    
    # Fields in `data`. `red`, `green`, `blue`, and `alpha` are optional for customizing the grid's color.
    foxglove_msgs/PackedElementField[] fields
    
    # Grid cell data, interpreted using `fields`, in row-major (y-major) order
    uint8[] data
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: foxglove_msgs/Vector2
    # foxglove_msgs/Vector2
    # A vector in 2D space that represents a direction only
    
    # Generated by https://github.com/foxglove/schemas
    
    # x coordinate length
    float64 x
    
    # y coordinate length
    float64 y
    
    ================================================================================
    MSG: foxglove_msgs/PackedElementField
    # foxglove_msgs/PackedElementField
    # A field present within each element in a byte array of packed elements.
    
    # Generated by https://github.com/foxglove/schemas
    
    # Name of the field
    string name
    
    # Byte offset from start of data buffer
    uint32 offset
    
    uint8 UNKNOWN=0
    uint8 UINT8=1
    uint8 INT8=2
    uint8 UINT16=3
    uint8 INT16=4
    uint8 UINT32=5
    uint8 INT32=6
    uint8 FLOAT32=7
    uint8 FLOAT64=8
    
    # Type of data in the field. Integers are stored using little-endian byte order.
    uint8 type
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Grid(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = {secs: 0, nsecs: 0}
    }

    if (msg.frame_id !== undefined) {
      resolved.frame_id = msg.frame_id;
    }
    else {
      resolved.frame_id = ''
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.Pose.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.Pose()
    }

    if (msg.column_count !== undefined) {
      resolved.column_count = msg.column_count;
    }
    else {
      resolved.column_count = 0
    }

    if (msg.cell_size !== undefined) {
      resolved.cell_size = Vector2.Resolve(msg.cell_size)
    }
    else {
      resolved.cell_size = new Vector2()
    }

    if (msg.row_stride !== undefined) {
      resolved.row_stride = msg.row_stride;
    }
    else {
      resolved.row_stride = 0
    }

    if (msg.cell_stride !== undefined) {
      resolved.cell_stride = msg.cell_stride;
    }
    else {
      resolved.cell_stride = 0
    }

    if (msg.fields !== undefined) {
      resolved.fields = new Array(msg.fields.length);
      for (let i = 0; i < resolved.fields.length; ++i) {
        resolved.fields[i] = PackedElementField.Resolve(msg.fields[i]);
      }
    }
    else {
      resolved.fields = []
    }

    if (msg.data !== undefined) {
      resolved.data = msg.data;
    }
    else {
      resolved.data = []
    }

    return resolved;
    }
};

module.exports = Grid;
