// Auto-generated. Do not edit!

// (in-package foxglove_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Point2 = require('./Point2.js');
let Color = require('./Color.js');

//-----------------------------------------------------------

class PointsAnnotation {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.type = null;
      this.points = null;
      this.outline_color = null;
      this.outline_colors = null;
      this.fill_color = null;
      this.thickness = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('points')) {
        this.points = initObj.points
      }
      else {
        this.points = [];
      }
      if (initObj.hasOwnProperty('outline_color')) {
        this.outline_color = initObj.outline_color
      }
      else {
        this.outline_color = new Color();
      }
      if (initObj.hasOwnProperty('outline_colors')) {
        this.outline_colors = initObj.outline_colors
      }
      else {
        this.outline_colors = [];
      }
      if (initObj.hasOwnProperty('fill_color')) {
        this.fill_color = initObj.fill_color
      }
      else {
        this.fill_color = new Color();
      }
      if (initObj.hasOwnProperty('thickness')) {
        this.thickness = initObj.thickness
      }
      else {
        this.thickness = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PointsAnnotation
    // Serialize message field [timestamp]
    bufferOffset = _serializer.time(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [type]
    bufferOffset = _serializer.uint8(obj.type, buffer, bufferOffset);
    // Serialize message field [points]
    // Serialize the length for message field [points]
    bufferOffset = _serializer.uint32(obj.points.length, buffer, bufferOffset);
    obj.points.forEach((val) => {
      bufferOffset = Point2.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [outline_color]
    bufferOffset = Color.serialize(obj.outline_color, buffer, bufferOffset);
    // Serialize message field [outline_colors]
    // Serialize the length for message field [outline_colors]
    bufferOffset = _serializer.uint32(obj.outline_colors.length, buffer, bufferOffset);
    obj.outline_colors.forEach((val) => {
      bufferOffset = Color.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [fill_color]
    bufferOffset = Color.serialize(obj.fill_color, buffer, bufferOffset);
    // Serialize message field [thickness]
    bufferOffset = _serializer.float64(obj.thickness, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PointsAnnotation
    let len;
    let data = new PointsAnnotation(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [type]
    data.type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [points]
    // Deserialize array length for message field [points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.points[i] = Point2.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [outline_color]
    data.outline_color = Color.deserialize(buffer, bufferOffset);
    // Deserialize message field [outline_colors]
    // Deserialize array length for message field [outline_colors]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.outline_colors = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.outline_colors[i] = Color.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [fill_color]
    data.fill_color = Color.deserialize(buffer, bufferOffset);
    // Deserialize message field [thickness]
    data.thickness = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 16 * object.points.length;
    length += 32 * object.outline_colors.length;
    return length + 89;
  }

  static datatype() {
    // Returns string type for a message object
    return 'foxglove_msgs/PointsAnnotation';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'df8c4c5f6b39712f6875eeb26aff0f86';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # foxglove_msgs/PointsAnnotation
    # An array of points on a 2D image
    
    # Generated by https://github.com/foxglove/schemas
    
    # Timestamp of annotation
    time timestamp
    
    uint8 UNKNOWN=0
    
    # Individual points: 0, 1, 2, ...
    uint8 POINTS=1
    
    # Closed polygon: 0-1, 1-2, ..., (n-1)-n, n-0
    uint8 LINE_LOOP=2
    
    # Connected line segments: 0-1, 1-2, ..., (n-1)-n
    uint8 LINE_STRIP=3
    
    # Individual line segments: 0-1, 2-3, 4-5, ...
    uint8 LINE_LIST=4
    
    # Type of points annotation to draw
    uint8 type
    
    # Points in 2D image coordinates (pixels)
    foxglove_msgs/Point2[] points
    
    # Outline color
    foxglove_msgs/Color outline_color
    
    # Per-point colors, if `type` is `POINTS`, or per-segment stroke colors, if `type` is `LINE_LIST`.
    foxglove_msgs/Color[] outline_colors
    
    # Fill color
    foxglove_msgs/Color fill_color
    
    # Stroke thickness in pixels
    float64 thickness
    
    ================================================================================
    MSG: foxglove_msgs/Point2
    # foxglove_msgs/Point2
    # A point representing a position in 2D space
    
    # Generated by https://github.com/foxglove/schemas
    
    # x coordinate position
    float64 x
    
    # y coordinate position
    float64 y
    
    ================================================================================
    MSG: foxglove_msgs/Color
    # foxglove_msgs/Color
    # A color in RGBA format
    
    # Generated by https://github.com/foxglove/schemas
    
    # Red value between 0 and 1
    float64 r
    
    # Green value between 0 and 1
    float64 g
    
    # Blue value between 0 and 1
    float64 b
    
    # Alpha value between 0 and 1
    float64 a
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PointsAnnotation(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = {secs: 0, nsecs: 0}
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.points !== undefined) {
      resolved.points = new Array(msg.points.length);
      for (let i = 0; i < resolved.points.length; ++i) {
        resolved.points[i] = Point2.Resolve(msg.points[i]);
      }
    }
    else {
      resolved.points = []
    }

    if (msg.outline_color !== undefined) {
      resolved.outline_color = Color.Resolve(msg.outline_color)
    }
    else {
      resolved.outline_color = new Color()
    }

    if (msg.outline_colors !== undefined) {
      resolved.outline_colors = new Array(msg.outline_colors.length);
      for (let i = 0; i < resolved.outline_colors.length; ++i) {
        resolved.outline_colors[i] = Color.Resolve(msg.outline_colors[i]);
      }
    }
    else {
      resolved.outline_colors = []
    }

    if (msg.fill_color !== undefined) {
      resolved.fill_color = Color.Resolve(msg.fill_color)
    }
    else {
      resolved.fill_color = new Color()
    }

    if (msg.thickness !== undefined) {
      resolved.thickness = msg.thickness;
    }
    else {
      resolved.thickness = 0.0
    }

    return resolved;
    }
};

// Constants for message
PointsAnnotation.Constants = {
  UNKNOWN: 0,
  POINTS: 1,
  LINE_LOOP: 2,
  LINE_STRIP: 3,
  LINE_LIST: 4,
}

module.exports = PointsAnnotation;
