// Auto-generated. Do not edit!

// (in-package foxglove_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class CameraCalibration {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.frame_id = null;
      this.width = null;
      this.height = null;
      this.distortion_model = null;
      this.D = null;
      this.K = null;
      this.R = null;
      this.P = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('frame_id')) {
        this.frame_id = initObj.frame_id
      }
      else {
        this.frame_id = '';
      }
      if (initObj.hasOwnProperty('width')) {
        this.width = initObj.width
      }
      else {
        this.width = 0;
      }
      if (initObj.hasOwnProperty('height')) {
        this.height = initObj.height
      }
      else {
        this.height = 0;
      }
      if (initObj.hasOwnProperty('distortion_model')) {
        this.distortion_model = initObj.distortion_model
      }
      else {
        this.distortion_model = '';
      }
      if (initObj.hasOwnProperty('D')) {
        this.D = initObj.D
      }
      else {
        this.D = [];
      }
      if (initObj.hasOwnProperty('K')) {
        this.K = initObj.K
      }
      else {
        this.K = new Array(9).fill(0);
      }
      if (initObj.hasOwnProperty('R')) {
        this.R = initObj.R
      }
      else {
        this.R = new Array(9).fill(0);
      }
      if (initObj.hasOwnProperty('P')) {
        this.P = initObj.P
      }
      else {
        this.P = new Array(12).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CameraCalibration
    // Serialize message field [timestamp]
    bufferOffset = _serializer.time(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [frame_id]
    bufferOffset = _serializer.string(obj.frame_id, buffer, bufferOffset);
    // Serialize message field [width]
    bufferOffset = _serializer.uint32(obj.width, buffer, bufferOffset);
    // Serialize message field [height]
    bufferOffset = _serializer.uint32(obj.height, buffer, bufferOffset);
    // Serialize message field [distortion_model]
    bufferOffset = _serializer.string(obj.distortion_model, buffer, bufferOffset);
    // Serialize message field [D]
    bufferOffset = _arraySerializer.float64(obj.D, buffer, bufferOffset, null);
    // Check that the constant length array field [K] has the right length
    if (obj.K.length !== 9) {
      throw new Error('Unable to serialize array field K - length must be 9')
    }
    // Serialize message field [K]
    bufferOffset = _arraySerializer.float64(obj.K, buffer, bufferOffset, 9);
    // Check that the constant length array field [R] has the right length
    if (obj.R.length !== 9) {
      throw new Error('Unable to serialize array field R - length must be 9')
    }
    // Serialize message field [R]
    bufferOffset = _arraySerializer.float64(obj.R, buffer, bufferOffset, 9);
    // Check that the constant length array field [P] has the right length
    if (obj.P.length !== 12) {
      throw new Error('Unable to serialize array field P - length must be 12')
    }
    // Serialize message field [P]
    bufferOffset = _arraySerializer.float64(obj.P, buffer, bufferOffset, 12);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CameraCalibration
    let len;
    let data = new CameraCalibration(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [frame_id]
    data.frame_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [width]
    data.width = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [height]
    data.height = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [distortion_model]
    data.distortion_model = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [D]
    data.D = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [K]
    data.K = _arrayDeserializer.float64(buffer, bufferOffset, 9)
    // Deserialize message field [R]
    data.R = _arrayDeserializer.float64(buffer, bufferOffset, 9)
    // Deserialize message field [P]
    data.P = _arrayDeserializer.float64(buffer, bufferOffset, 12)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.frame_id.length;
    length += object.distortion_model.length;
    length += 8 * object.D.length;
    return length + 268;
  }

  static datatype() {
    // Returns string type for a message object
    return 'foxglove_msgs/CameraCalibration';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a208aa8d11a148c3edd1fc117b079143';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # foxglove_msgs/CameraCalibration
    # Camera calibration parameters
    
    # Generated by https://github.com/foxglove/schemas
    
    # Timestamp of calibration data
    time timestamp
    
    # Frame of reference for the camera. The origin of the frame is the optical center of the camera. +x points to the right in the image, +y points down, and +z points into the plane of the image.
    string frame_id
    
    # Image width
    uint32 width
    
    # Image height
    uint32 height
    
    # Name of distortion model
    # 
    # Supported values: `plumb_bob` and `rational_polynomial`
    string distortion_model
    
    # Distortion parameters
    float64[] D
    
    # Intrinsic camera matrix (3x3 row-major matrix)
    # 
    # A 3x3 row-major matrix for the raw (distorted) image.
    # 
    # Projects 3D points in the camera coordinate frame to 2D pixel coordinates using the focal lengths (fx, fy) and principal point (cx, cy).
    # 
    # ```
    #     [fx  0 cx]
    # K = [ 0 fy cy]
    #     [ 0  0  1]
    # ```
    float64[9] K
    
    # Rectification matrix (stereo cameras only, 3x3 row-major matrix)
    # 
    # A rotation matrix aligning the camera coordinate system to the ideal stereo image plane so that epipolar lines in both stereo images are parallel.
    float64[9] R
    
    # Projection/camera matrix (3x4 row-major matrix)
    # 
    # ```
    #     [fx'  0  cx' Tx]
    # P = [ 0  fy' cy' Ty]
    #     [ 0   0   1   0]
    # ```
    # 
    # By convention, this matrix specifies the intrinsic (camera) matrix of the processed (rectified) image. That is, the left 3x3 portion is the normal camera intrinsic matrix for the rectified image.
    # 
    # It projects 3D points in the camera coordinate frame to 2D pixel coordinates using the focal lengths (fx', fy') and principal point (cx', cy') - these may differ from the values in K.
    # 
    # For monocular cameras, Tx = Ty = 0. Normally, monocular cameras will also have R = the identity and P[1:3,1:3] = K.
    # 
    # For a stereo pair, the fourth column [Tx Ty 0]' is related to the position of the optical center of the second camera in the first camera's frame. We assume Tz = 0 so both cameras are in the same stereo image plane. The first camera always has Tx = Ty = 0. For the right (second) camera of a horizontal stereo pair, Ty = 0 and Tx = -fx' * B, where B is the baseline between the cameras.
    # 
    # Given a 3D point [X Y Z]', the projection (x, y) of the point onto the rectified image is given by:
    # 
    # ```
    # [u v w]' = P * [X Y Z 1]'
    #        x = u / w
    #        y = v / w
    # ```
    # 
    # This holds for both images of a stereo pair.
    float64[12] P
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CameraCalibration(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = {secs: 0, nsecs: 0}
    }

    if (msg.frame_id !== undefined) {
      resolved.frame_id = msg.frame_id;
    }
    else {
      resolved.frame_id = ''
    }

    if (msg.width !== undefined) {
      resolved.width = msg.width;
    }
    else {
      resolved.width = 0
    }

    if (msg.height !== undefined) {
      resolved.height = msg.height;
    }
    else {
      resolved.height = 0
    }

    if (msg.distortion_model !== undefined) {
      resolved.distortion_model = msg.distortion_model;
    }
    else {
      resolved.distortion_model = ''
    }

    if (msg.D !== undefined) {
      resolved.D = msg.D;
    }
    else {
      resolved.D = []
    }

    if (msg.K !== undefined) {
      resolved.K = msg.K;
    }
    else {
      resolved.K = new Array(9).fill(0)
    }

    if (msg.R !== undefined) {
      resolved.R = msg.R;
    }
    else {
      resolved.R = new Array(9).fill(0)
    }

    if (msg.P !== undefined) {
      resolved.P = msg.P;
    }
    else {
      resolved.P = new Array(12).fill(0)
    }

    return resolved;
    }
};

module.exports = CameraCalibration;
