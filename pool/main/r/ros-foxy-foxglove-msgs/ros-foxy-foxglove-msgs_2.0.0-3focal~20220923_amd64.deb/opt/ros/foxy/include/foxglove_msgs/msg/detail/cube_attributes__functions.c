// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from foxglove_msgs:msg/CubeAttributes.idl
// generated code does not contain a copyright notice
#include "foxglove_msgs/msg/detail/cube_attributes__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `pose`
#include "geometry_msgs/msg/detail/pose__functions.h"
// Member `size`
#include "geometry_msgs/msg/detail/vector3__functions.h"
// Member `color`
#include "foxglove_msgs/msg/detail/color__functions.h"

bool
foxglove_msgs__msg__CubeAttributes__init(foxglove_msgs__msg__CubeAttributes * msg)
{
  if (!msg) {
    return false;
  }
  // pose
  if (!geometry_msgs__msg__Pose__init(&msg->pose)) {
    foxglove_msgs__msg__CubeAttributes__fini(msg);
    return false;
  }
  // size
  if (!geometry_msgs__msg__Vector3__init(&msg->size)) {
    foxglove_msgs__msg__CubeAttributes__fini(msg);
    return false;
  }
  // color
  if (!foxglove_msgs__msg__Color__init(&msg->color)) {
    foxglove_msgs__msg__CubeAttributes__fini(msg);
    return false;
  }
  return true;
}

void
foxglove_msgs__msg__CubeAttributes__fini(foxglove_msgs__msg__CubeAttributes * msg)
{
  if (!msg) {
    return;
  }
  // pose
  geometry_msgs__msg__Pose__fini(&msg->pose);
  // size
  geometry_msgs__msg__Vector3__fini(&msg->size);
  // color
  foxglove_msgs__msg__Color__fini(&msg->color);
}

foxglove_msgs__msg__CubeAttributes *
foxglove_msgs__msg__CubeAttributes__create()
{
  foxglove_msgs__msg__CubeAttributes * msg = (foxglove_msgs__msg__CubeAttributes *)malloc(sizeof(foxglove_msgs__msg__CubeAttributes));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(foxglove_msgs__msg__CubeAttributes));
  bool success = foxglove_msgs__msg__CubeAttributes__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
foxglove_msgs__msg__CubeAttributes__destroy(foxglove_msgs__msg__CubeAttributes * msg)
{
  if (msg) {
    foxglove_msgs__msg__CubeAttributes__fini(msg);
  }
  free(msg);
}


bool
foxglove_msgs__msg__CubeAttributes__Sequence__init(foxglove_msgs__msg__CubeAttributes__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  foxglove_msgs__msg__CubeAttributes * data = NULL;
  if (size) {
    data = (foxglove_msgs__msg__CubeAttributes *)calloc(size, sizeof(foxglove_msgs__msg__CubeAttributes));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = foxglove_msgs__msg__CubeAttributes__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        foxglove_msgs__msg__CubeAttributes__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
foxglove_msgs__msg__CubeAttributes__Sequence__fini(foxglove_msgs__msg__CubeAttributes__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      foxglove_msgs__msg__CubeAttributes__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

foxglove_msgs__msg__CubeAttributes__Sequence *
foxglove_msgs__msg__CubeAttributes__Sequence__create(size_t size)
{
  foxglove_msgs__msg__CubeAttributes__Sequence * array = (foxglove_msgs__msg__CubeAttributes__Sequence *)malloc(sizeof(foxglove_msgs__msg__CubeAttributes__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = foxglove_msgs__msg__CubeAttributes__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
foxglove_msgs__msg__CubeAttributes__Sequence__destroy(foxglove_msgs__msg__CubeAttributes__Sequence * array)
{
  if (array) {
    foxglove_msgs__msg__CubeAttributes__Sequence__fini(array);
  }
  free(array);
}
