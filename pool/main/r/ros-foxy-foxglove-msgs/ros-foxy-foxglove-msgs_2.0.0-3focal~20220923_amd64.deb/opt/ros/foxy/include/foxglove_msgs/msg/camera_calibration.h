// generated from rosidl_generator_c/resource/idl.h.em
// with input from foxglove_msgs:msg/CameraCalibration.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__CAMERA_CALIBRATION_H_
#define FOXGLOVE_MSGS__MSG__CAMERA_CALIBRATION_H_

#include "foxglove_msgs/msg/detail/camera_calibration__struct.h"
#include "foxglove_msgs/msg/detail/camera_calibration__functions.h"
#include "foxglove_msgs/msg/detail/camera_calibration__type_support.h"

#endif  // FOXGLOVE_MSGS__MSG__CAMERA_CALIBRATION_H_
