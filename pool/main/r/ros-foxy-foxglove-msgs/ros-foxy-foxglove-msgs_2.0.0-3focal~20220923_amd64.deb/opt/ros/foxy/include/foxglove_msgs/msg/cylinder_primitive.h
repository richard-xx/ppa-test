// generated from rosidl_generator_c/resource/idl.h.em
// with input from foxglove_msgs:msg/CylinderPrimitive.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__CYLINDER_PRIMITIVE_H_
#define FOXGLOVE_MSGS__MSG__CYLINDER_PRIMITIVE_H_

#include "foxglove_msgs/msg/detail/cylinder_primitive__struct.h"
#include "foxglove_msgs/msg/detail/cylinder_primitive__functions.h"
#include "foxglove_msgs/msg/detail/cylinder_primitive__type_support.h"

#endif  // FOXGLOVE_MSGS__MSG__CYLINDER_PRIMITIVE_H_
