// generated from rosidl_generator_c/resource/idl.h.em
// with input from foxglove_msgs:msg/CompressedVideo.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__COMPRESSED_VIDEO_H_
#define FOXGLOVE_MSGS__MSG__COMPRESSED_VIDEO_H_

#include "foxglove_msgs/msg/detail/compressed_video__struct.h"
#include "foxglove_msgs/msg/detail/compressed_video__functions.h"
#include "foxglove_msgs/msg/detail/compressed_video__type_support.h"

#endif  // FOXGLOVE_MSGS__MSG__COMPRESSED_VIDEO_H_
