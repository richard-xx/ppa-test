// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__CONE_ATTRIBUTES_HPP_
#define FOXGLOVE_MSGS__MSG__CONE_ATTRIBUTES_HPP_

#include "foxglove_msgs/msg/detail/cone_attributes__struct.hpp"
#include "foxglove_msgs/msg/detail/cone_attributes__builder.hpp"
#include "foxglove_msgs/msg/detail/cone_attributes__traits.hpp"
#include "foxglove_msgs/msg/detail/cone_attributes__type_support.hpp"

#endif  // FOXGLOVE_MSGS__MSG__CONE_ATTRIBUTES_HPP_
