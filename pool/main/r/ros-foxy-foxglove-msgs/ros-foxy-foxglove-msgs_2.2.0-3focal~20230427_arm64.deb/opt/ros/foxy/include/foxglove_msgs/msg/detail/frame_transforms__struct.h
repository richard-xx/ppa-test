// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from foxglove_msgs:msg/FrameTransforms.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__FRAME_TRANSFORMS__STRUCT_H_
#define FOXGLOVE_MSGS__MSG__DETAIL__FRAME_TRANSFORMS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'transforms'
#include "foxglove_msgs/msg/detail/frame_transform__struct.h"

// Struct defined in msg/FrameTransforms in the package foxglove_msgs.
typedef struct foxglove_msgs__msg__FrameTransforms
{
  foxglove_msgs__msg__FrameTransform__Sequence transforms;
} foxglove_msgs__msg__FrameTransforms;

// Struct for a sequence of foxglove_msgs__msg__FrameTransforms.
typedef struct foxglove_msgs__msg__FrameTransforms__Sequence
{
  foxglove_msgs__msg__FrameTransforms * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} foxglove_msgs__msg__FrameTransforms__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__FRAME_TRANSFORMS__STRUCT_H_
