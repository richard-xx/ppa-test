// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from foxglove_msgs:msg/CircleAnnotation.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__CIRCLE_ANNOTATION__STRUCT_H_
#define FOXGLOVE_MSGS__MSG__DETAIL__CIRCLE_ANNOTATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'timestamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'position'
#include "foxglove_msgs/msg/detail/point2__struct.h"
// Member 'fill_color'
// Member 'outline_color'
#include "foxglove_msgs/msg/detail/color__struct.h"

// Struct defined in msg/CircleAnnotation in the package foxglove_msgs.
typedef struct foxglove_msgs__msg__CircleAnnotation
{
  builtin_interfaces__msg__Time timestamp;
  foxglove_msgs__msg__Point2 position;
  double diameter;
  double thickness;
  foxglove_msgs__msg__Color fill_color;
  foxglove_msgs__msg__Color outline_color;
} foxglove_msgs__msg__CircleAnnotation;

// Struct for a sequence of foxglove_msgs__msg__CircleAnnotation.
typedef struct foxglove_msgs__msg__CircleAnnotation__Sequence
{
  foxglove_msgs__msg__CircleAnnotation * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} foxglove_msgs__msg__CircleAnnotation__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__CIRCLE_ANNOTATION__STRUCT_H_
