// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from foxglove_msgs:msg/ModelPrimitive.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__MODEL_PRIMITIVE__TRAITS_HPP_
#define FOXGLOVE_MSGS__MSG__DETAIL__MODEL_PRIMITIVE__TRAITS_HPP_

#include "foxglove_msgs/msg/detail/model_primitive__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__traits.hpp"
// Member 'scale'
#include "geometry_msgs/msg/detail/vector3__traits.hpp"
// Member 'color'
#include "foxglove_msgs/msg/detail/color__traits.hpp"

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<foxglove_msgs::msg::ModelPrimitive>()
{
  return "foxglove_msgs::msg::ModelPrimitive";
}

template<>
inline const char * name<foxglove_msgs::msg::ModelPrimitive>()
{
  return "foxglove_msgs/msg/ModelPrimitive";
}

template<>
struct has_fixed_size<foxglove_msgs::msg::ModelPrimitive>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<foxglove_msgs::msg::ModelPrimitive>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<foxglove_msgs::msg::ModelPrimitive>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__MODEL_PRIMITIVE__TRAITS_HPP_
