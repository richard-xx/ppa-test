// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from foxglove_msgs:msg/Color.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__DETAIL__COLOR__STRUCT_H_
#define FOXGLOVE_MSGS__MSG__DETAIL__COLOR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Struct defined in msg/Color in the package foxglove_msgs.
typedef struct foxglove_msgs__msg__Color
{
  double r;
  double g;
  double b;
  double a;
} foxglove_msgs__msg__Color;

// Struct for a sequence of foxglove_msgs__msg__Color.
typedef struct foxglove_msgs__msg__Color__Sequence
{
  foxglove_msgs__msg__Color * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} foxglove_msgs__msg__Color__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // FOXGLOVE_MSGS__MSG__DETAIL__COLOR__STRUCT_H_
