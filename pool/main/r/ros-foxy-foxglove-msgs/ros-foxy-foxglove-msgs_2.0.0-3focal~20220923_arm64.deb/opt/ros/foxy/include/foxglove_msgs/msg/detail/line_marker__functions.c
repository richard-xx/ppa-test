// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from foxglove_msgs:msg/LineMarker.idl
// generated code does not contain a copyright notice
#include "foxglove_msgs/msg/detail/line_marker__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `pose`
#include "geometry_msgs/msg/detail/pose__functions.h"
// Member `points`
#include "geometry_msgs/msg/detail/point__functions.h"
// Member `color`
// Member `colors`
#include "foxglove_msgs/msg/detail/color__functions.h"
// Member `indices`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
foxglove_msgs__msg__LineMarker__init(foxglove_msgs__msg__LineMarker * msg)
{
  if (!msg) {
    return false;
  }
  // type
  // pose
  if (!geometry_msgs__msg__Pose__init(&msg->pose)) {
    foxglove_msgs__msg__LineMarker__fini(msg);
    return false;
  }
  // thickness
  // scale_invariant
  // points
  if (!geometry_msgs__msg__Point__Sequence__init(&msg->points, 0)) {
    foxglove_msgs__msg__LineMarker__fini(msg);
    return false;
  }
  // color
  if (!foxglove_msgs__msg__Color__init(&msg->color)) {
    foxglove_msgs__msg__LineMarker__fini(msg);
    return false;
  }
  // colors
  if (!foxglove_msgs__msg__Color__Sequence__init(&msg->colors, 0)) {
    foxglove_msgs__msg__LineMarker__fini(msg);
    return false;
  }
  // indices
  if (!rosidl_runtime_c__uint32__Sequence__init(&msg->indices, 0)) {
    foxglove_msgs__msg__LineMarker__fini(msg);
    return false;
  }
  return true;
}

void
foxglove_msgs__msg__LineMarker__fini(foxglove_msgs__msg__LineMarker * msg)
{
  if (!msg) {
    return;
  }
  // type
  // pose
  geometry_msgs__msg__Pose__fini(&msg->pose);
  // thickness
  // scale_invariant
  // points
  geometry_msgs__msg__Point__Sequence__fini(&msg->points);
  // color
  foxglove_msgs__msg__Color__fini(&msg->color);
  // colors
  foxglove_msgs__msg__Color__Sequence__fini(&msg->colors);
  // indices
  rosidl_runtime_c__uint32__Sequence__fini(&msg->indices);
}

foxglove_msgs__msg__LineMarker *
foxglove_msgs__msg__LineMarker__create()
{
  foxglove_msgs__msg__LineMarker * msg = (foxglove_msgs__msg__LineMarker *)malloc(sizeof(foxglove_msgs__msg__LineMarker));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(foxglove_msgs__msg__LineMarker));
  bool success = foxglove_msgs__msg__LineMarker__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
foxglove_msgs__msg__LineMarker__destroy(foxglove_msgs__msg__LineMarker * msg)
{
  if (msg) {
    foxglove_msgs__msg__LineMarker__fini(msg);
  }
  free(msg);
}


bool
foxglove_msgs__msg__LineMarker__Sequence__init(foxglove_msgs__msg__LineMarker__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  foxglove_msgs__msg__LineMarker * data = NULL;
  if (size) {
    data = (foxglove_msgs__msg__LineMarker *)calloc(size, sizeof(foxglove_msgs__msg__LineMarker));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = foxglove_msgs__msg__LineMarker__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        foxglove_msgs__msg__LineMarker__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
foxglove_msgs__msg__LineMarker__Sequence__fini(foxglove_msgs__msg__LineMarker__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      foxglove_msgs__msg__LineMarker__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

foxglove_msgs__msg__LineMarker__Sequence *
foxglove_msgs__msg__LineMarker__Sequence__create(size_t size)
{
  foxglove_msgs__msg__LineMarker__Sequence * array = (foxglove_msgs__msg__LineMarker__Sequence *)malloc(sizeof(foxglove_msgs__msg__LineMarker__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = foxglove_msgs__msg__LineMarker__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
foxglove_msgs__msg__LineMarker__Sequence__destroy(foxglove_msgs__msg__LineMarker__Sequence * array)
{
  if (array) {
    foxglove_msgs__msg__LineMarker__Sequence__fini(array);
  }
  free(array);
}
