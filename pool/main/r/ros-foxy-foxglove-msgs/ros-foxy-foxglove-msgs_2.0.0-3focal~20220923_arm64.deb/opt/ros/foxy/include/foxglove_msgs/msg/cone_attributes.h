// generated from rosidl_generator_c/resource/idl.h.em
// with input from foxglove_msgs:msg/ConeAttributes.idl
// generated code does not contain a copyright notice

#ifndef FOXGLOVE_MSGS__MSG__CONE_ATTRIBUTES_H_
#define FOXGLOVE_MSGS__MSG__CONE_ATTRIBUTES_H_

#include "foxglove_msgs/msg/detail/cone_attributes__struct.h"
#include "foxglove_msgs/msg/detail/cone_attributes__functions.h"
#include "foxglove_msgs/msg/detail/cone_attributes__type_support.h"

#endif  // FOXGLOVE_MSGS__MSG__CONE_ATTRIBUTES_H_
