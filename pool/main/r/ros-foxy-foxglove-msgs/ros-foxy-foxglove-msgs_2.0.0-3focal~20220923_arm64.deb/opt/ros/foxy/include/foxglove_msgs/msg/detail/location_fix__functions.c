// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from foxglove_msgs:msg/LocationFix.idl
// generated code does not contain a copyright notice
#include "foxglove_msgs/msg/detail/location_fix__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


bool
foxglove_msgs__msg__LocationFix__init(foxglove_msgs__msg__LocationFix * msg)
{
  if (!msg) {
    return false;
  }
  // latitude
  // longitude
  // altitude
  // position_covariance
  // position_covariance_type
  return true;
}

void
foxglove_msgs__msg__LocationFix__fini(foxglove_msgs__msg__LocationFix * msg)
{
  if (!msg) {
    return;
  }
  // latitude
  // longitude
  // altitude
  // position_covariance
  // position_covariance_type
}

foxglove_msgs__msg__LocationFix *
foxglove_msgs__msg__LocationFix__create()
{
  foxglove_msgs__msg__LocationFix * msg = (foxglove_msgs__msg__LocationFix *)malloc(sizeof(foxglove_msgs__msg__LocationFix));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(foxglove_msgs__msg__LocationFix));
  bool success = foxglove_msgs__msg__LocationFix__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
foxglove_msgs__msg__LocationFix__destroy(foxglove_msgs__msg__LocationFix * msg)
{
  if (msg) {
    foxglove_msgs__msg__LocationFix__fini(msg);
  }
  free(msg);
}


bool
foxglove_msgs__msg__LocationFix__Sequence__init(foxglove_msgs__msg__LocationFix__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  foxglove_msgs__msg__LocationFix * data = NULL;
  if (size) {
    data = (foxglove_msgs__msg__LocationFix *)calloc(size, sizeof(foxglove_msgs__msg__LocationFix));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = foxglove_msgs__msg__LocationFix__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        foxglove_msgs__msg__LocationFix__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
foxglove_msgs__msg__LocationFix__Sequence__fini(foxglove_msgs__msg__LocationFix__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      foxglove_msgs__msg__LocationFix__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

foxglove_msgs__msg__LocationFix__Sequence *
foxglove_msgs__msg__LocationFix__Sequence__create(size_t size)
{
  foxglove_msgs__msg__LocationFix__Sequence * array = (foxglove_msgs__msg__LocationFix__Sequence *)malloc(sizeof(foxglove_msgs__msg__LocationFix__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = foxglove_msgs__msg__LocationFix__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
foxglove_msgs__msg__LocationFix__Sequence__destroy(foxglove_msgs__msg__LocationFix__Sequence * array)
{
  if (array) {
    foxglove_msgs__msg__LocationFix__Sequence__fini(array);
  }
  free(array);
}
