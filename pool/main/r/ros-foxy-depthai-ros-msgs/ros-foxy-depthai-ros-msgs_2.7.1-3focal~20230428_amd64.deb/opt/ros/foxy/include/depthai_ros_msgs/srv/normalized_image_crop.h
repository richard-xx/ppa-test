// generated from rosidl_generator_c/resource/idl.h.em
// with input from depthai_ros_msgs:srv/NormalizedImageCrop.idl
// generated code does not contain a copyright notice

#ifndef DEPTHAI_ROS_MSGS__SRV__NORMALIZED_IMAGE_CROP_H_
#define DEPTHAI_ROS_MSGS__SRV__NORMALIZED_IMAGE_CROP_H_

#include "depthai_ros_msgs/srv/detail/normalized_image_crop__struct.h"
#include "depthai_ros_msgs/srv/detail/normalized_image_crop__functions.h"
#include "depthai_ros_msgs/srv/detail/normalized_image_crop__type_support.h"

#endif  // DEPTHAI_ROS_MSGS__SRV__NORMALIZED_IMAGE_CROP_H_
