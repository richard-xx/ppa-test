// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DEPTHAI_ROS_MSGS__SRV__NORMALIZED_IMAGE_CROP_HPP_
#define DEPTHAI_ROS_MSGS__SRV__NORMALIZED_IMAGE_CROP_HPP_

#include "depthai_ros_msgs/srv/detail/normalized_image_crop__struct.hpp"
#include "depthai_ros_msgs/srv/detail/normalized_image_crop__builder.hpp"
#include "depthai_ros_msgs/srv/detail/normalized_image_crop__traits.hpp"
#include "depthai_ros_msgs/srv/detail/normalized_image_crop__type_support.hpp"

#endif  // DEPTHAI_ROS_MSGS__SRV__NORMALIZED_IMAGE_CROP_HPP_
