// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DEPTHAI_ROS_MSGS__SRV__TRIGGER_NAMED_HPP_
#define DEPTHAI_ROS_MSGS__SRV__TRIGGER_NAMED_HPP_

#include "depthai_ros_msgs/srv/detail/trigger_named__struct.hpp"
#include "depthai_ros_msgs/srv/detail/trigger_named__builder.hpp"
#include "depthai_ros_msgs/srv/detail/trigger_named__traits.hpp"

#endif  // DEPTHAI_ROS_MSGS__SRV__TRIGGER_NAMED_HPP_
